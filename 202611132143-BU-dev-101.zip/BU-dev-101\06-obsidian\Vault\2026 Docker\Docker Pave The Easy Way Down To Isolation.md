---
planner:
  log:
    - start: 2026-11-02 17:44:36
      end: 2026-11-02 21:59:37
    - start: 2026-11-02 22:36:11
      end: 2026-11-02 22:36:17
tags:
  - Docker
---
Notes @ZL

## Docker Service Building Components (CVIN)

There are four main components to build a docker service. They are **C**ontainer, **V**olume, **I**mage, **N**etwork (**CVIN** for short).

These four components are also corresponding to useful docker commands.
```bash
docker contianer ls -a
docker volume ls
docker image ls -a
docker network ls -a
```

 Also get help for each component can be done like this.
```bash
docker container --help
docker volume --help
docker image --help
docker network --help
```

Use `docker inspect` to check CVIN
```bash
docker inspect <CONTAINER ID>
docker inpect <VOLUME ID>
docker inspect <IMAGE ID>
docker inspect <NETWORK ID>
```

Now, you can see the pattern and why we remember the four components as CVIN.

## Docker Common Vulnerabilities and Exposures (CVES)

Check the official doc here: https://docs.docker.com/dhi/explore/security-concepts/cves/
```bash
docker login -u <username>
docker scout cves
```

Now you see the reason abbr. of the four components is CVIN, it is like a combo.

## Docker Service Building Workflow

Docker services are only available in a container. Image, network, Volume construct the service you need inside a container.

Images are like ISO Burning into a disc old days. You "burn" your app into image for later usage.
Volume can be inside of a container or on a host, it is optional for some apps.
Network can be optional, docker will use some default network if you don't specify.
![[docker-build-workflow.png]]

## Docker Build Image for Your App

Before doing anything, create three files under the root of your app workspace.

Use commands for Linux OS
```bash
echo .dockerignore
echo Dockfile
echo Compose.yml
```

Use commands for Windows OS
```powershell
New-Item .dockerignore -ItemType File
New-Item Dockfile -ItemType File
New-Item Compose.yml -ItemType File
```

To build a clean image, you need exclude unnecessary files, folders in your workspace in `.dockerignore`
```dockerignore
# git
.gitignore

# vscode workspace settings
.vscode

# docker
.dockerignore
Dockerfile*
Docker-Compose*.yml
Compose*.yml

# virtual environment
venv
.venv

# language environment
target
```

The we go to open `Dockerfile` and write some Docker commands.
The operation is just like move some items from your folder A to folder B.

#### Build An Image for a Django Project

Reference: https://docs.docker.com/guides/django/

Start a Django project
```powershell
# make root directory && django venv
mkdir django-project
cd django-project
python -m venv .venv
code .
# install dependencies
pip install django gunicorn
pip freeze > requirements.txt
# startproject
django-admin startprojects myapp
```

Project structure
![[django-project-structure-20261102.png]]

Write a `Dockerfile` for Django project with **caching** strategy
```dockerfile
FROM python
WORKDIR /app
ENV PYTHONDONTWRITEBYTECODE=1 \
PYTHONUNBUFFERED=1
COPY ./requirements.txt /app
RUN pip install -r requirements.txt
COPY . .
CMD ["gunicorn", "myapp.wsgi:application", "--bind", "0.0.0.0:8000"]
```

Build Image
```bash
docker build . -t pepehand/my-django-web-1
```

Run the image
```bash
docker run -d -p 8000:8000 --name django-web-1 pepehand/my-django-web-1
```

Then integrate `Dockerfile` into `Compose.yml`
```Compose.yml
services:
  web:
    build: .
    restart: unless-stopped
    ports:
      - "8000:8000"
    volumes:
      - .:/app
```

Build Service
```bash
docker compose up --build -d
```

Check Service healthy
```powershell
curl.exe localhost:8000
```

#### Build An Image for Rust Axum API Project

Write a `Dockerfile` for Rust Axum API with **multi-stage** strategy
```dockerfile
FROM rust AS planner
WORKDIR /app
COPY . .
RUN apt-get update && apt-get -y curl
RUN cargo install cargo-chef
RUN cargo chef prepare --recipe-path recipe.json

FROM rust AS cacher
WORKDIR /app
COPY --from=planner /app/recipe.json /app
RUN cargo install cargo-chef
RUN cargo chef cook --recipe-path recipe.json

FROM rust AS builder
WORKDIR /app
COPY --from=cacher /usr/local/cargo /usr/local/cargo
COPY . .
RUN cargo build --release

FROM debian:bookworm-slim
WORKDIR /app
COPY --from=builder /target/release/<your project name> /app
CMD ["./<your project name>"]
```

Build Image
```bash
docker build . -t diamondhand/axum-api-1
```

And then `Compose.yml`
```Compose.yml
services:
	api:
		build: .
		restart: always
		port:
			- 8080:8080
		healthcheck:
			test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
			intervals: 30s
			timeout: 5s
			retries: 3
			start_period: 10s
```

Build Service
```bash
docker compose up --build -d
```

#### Build A Postgres + pdAdmin4 Service As a Sandbox

Create `Compose.yml` under your workspace
```Compose.yml
services:
  db:
    container_name: postgres_container
    image: postgres:alpine
    restart: always
    environment:
      POSTGRES_USER: admin
      POSTGRES_PASSWORD: admin
      POSTGRES_DB: test_db
    ports:
      - "5432:5432"
  pgadmin:
    container_name: pgadmin4_container
    image: dpage/pgadmin4
    restart: always
    environment:
      PGADMIN_DEFAULT_EMAIL: admin@admin.com
      PGADMIN_DEFAULT_PASSWORD: root
    ports:
      - 5050:80
volumes:
  postgres_data:
```

Populate your database and then benchmark
1. ai, official doc is dogwater btw
2. guide @dev.to: https://dev.to/ftisiot/how-to-use-pgbench-to-test-postgresqlr-performance-4m6h)
```bash
> docker compose up --build -d
> docker exec -it postgres_container sh
> pgbench -h localhost -p 5432 -U postgres -i -s 10 test_db
```

Connect with your Postgres database via pgAdmin4 or `dbeaver`

Sneak into a container and navigate
```bash
docker exec -it <CONTAINER ID> /bin/sh
```

## Docker Log and History

You can use the following method to check docker building process to debug,  and history to see building layers.
```bash
docker logs <CONTAINER ID>
```

```bash
docker history <IMAGE ID>
```

## Visual Studio + Docker

You don't need handwrite a `Dockerfile` for a project in visual studio.
You just need right-click your project then `add` then `choose` `Dockerfile`.

go and open View -> Terminal
```powershell
docker build . -t monkas/blazor-web-1
```

```powershell
docker run -d -p 8001:8001 --name <CONTAINER NAME> monkas/blazer-web-1
```

![[visualstudio-dockerfile.png|483]]


But Visual Studio cannot generate a `Compose.yml` for some reason I am unaware. I did search over AI, internet, but found nothing. It means you have to handwrite a `Compose.yml` by yourself.
```Compose.yml
services:
  api:
    build: .
    restart: always
    ports:
      - "8080:8080"
    healthcheck:
      test: ["CMD", "curl", "-fsS", "http://localhost:8080/"]
      interval: 30s
      timeout: 5s
      retries: 3
      start_period: 10s
```

![[visualstudio-compose.png]]


## Docker Buildx Regression Bugfix

Date
2026-10-30

Problem Description
`docker build . -t <tagname>` succeeded without any warnings or errors
`docker compose up --build -d` failed at the beginning of the process, error is always the same.
```log
[+] Building 0.0s (1/1) FINISHED
=> [internal] load local bake definitions
0.0s
=> => reading from stdin 507B
0.0s
additional privileges requested: pass "--allow=fs.read=Dockerfile" to grant requested privileges
```

Host info
```powershell
> Get-ComputerInfo
WindowsBuildLabEx                                       : 19041.1.amd64fre.vb_release.191206-1406
WindowsCurrentVersion                                   : 6.3
WindowsEditionId                                        : Professional
WindowsInstallationType                                 : Client
# ...
```

Docker info
```bash
> docker info
Client:
 Version:    29.9.2
 ontext:    desktop-linux
 buildx: Docker Buildx (Docker Inc.)
Debug Mode: false
Plugins:
 ...
 buildx: Docker Buildx (Docker Inc.)
	Version:  v0.38.0
	Path:     ~\.docker\cli-plugins\docker-buildx.exe
 ...
```

Docker Buildx info
```bash
> docker buildx version
github.com/docker/buildx v0.37.0 ac30b249211430b85fb8f37b6e7154b5c47ba0b6

> docker buildx list
NAME/NODE           DRIVER/ENDPOINT     STATUS    BUILDKIT   PLATFORMS
default             docker
 \_ default          \_ default         running   v0.34.0    linux/amd64 (+4), linux/arm64, linux/arm (+2), linux/ppc64le, (2 more)
desktop-linux*      docker
 \_ desktop-linux    \_ desktop-linux   running   v0.34.0    linux/amd64 (+4), linux/arm64, linux/arm (+2), linux/ppc64le, (2 more)
```

After days, hours of debugging and search on internet, the root cause is `Docker Buildx regression Bug`. Docker Buildx release page at https://github.com/docker/buildx/releases. Navigate the page and download v0.37.0, v0.36.1 of `buildx-v0.XX.X.windows-amd64-exe`
##### Here is experimental tests to replicate the bug

Replace with `buildx-v0.37.0`
1. go to host `~\.docker\cli-plugins\` and then move `docker-buildx.exe` out
2. copy `buildx-v0.37.0.windows-amd64.exe` into `~\.docker\cli-plugins\`
3. rename `buildx-v0.37.0.windows-amd64.exe` to `docker-buildx.exe`
4. retry `docker compose up --build -d`
Result: <font color="#00b050">success</font>

Replace with `buildx-v0.36.1`
Result: <font color="#00b050">success</font>

Replace back with `buildx-v0.38.0`
Result: <font color="#ff0000">failed</font> with the same error


## Image Size and Consideration of slim

Please consider prune and make your image as small as possible.

1. The image size of Rust actix-web-1 is huge by default, need dehydrate it with multi stage building.
2. The image size of Python Django is huge by default, you need dehydrate it.
3. The image size of ASP.NET Blazor app is relatively small by default.