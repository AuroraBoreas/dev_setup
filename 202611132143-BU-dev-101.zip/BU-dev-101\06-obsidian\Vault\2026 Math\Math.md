

## Group Theory

```markdown
Group Theory
1. 🌔 S B I: set, binary, identity
2. 🐒 A I: associativity, inverse
```

## Calculus

```markdown
Calculus
1. 🚀极连微积超函数
2. 🍭序列截面矢空间
3. 🌌多变多积向量场
```

## Algebraic