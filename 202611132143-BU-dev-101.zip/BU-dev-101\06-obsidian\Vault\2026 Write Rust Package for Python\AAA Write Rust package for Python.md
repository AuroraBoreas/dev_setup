---
planner:
  log:
    - start: 2026-10-22 01:12:23
      end: 2026-10-22 01:12:41
tags:
  - Done
---
2026-10-21, @ZL


## General workflow
1. start your Python project with `uv` [[Start your Python project with uv]]
2. once your project is ready, create a new directory as Rust project under src/{projectname}, it's same level of `__init__.py` file. in my case, it is `house` directory showed as follow image. ![[Tree-Rust-Project-House20261021203834.png]]
3. work with Maturin then write some code [[PyO3 and Maturin]]
4. `import house` in your Python `__init__.py` file and use the functions as you wish. No overthinking needed at all, just `import house`. But it is totally different with Python user-defined module like `config.py`, you have to use `from one.house.config import config`. It means you **cannot mix** Python modules with Rust Crate in this workflow.![[Code-import-rust-package202610212122.png]]

## Afterword
This workflow is not complicated, Python project -> PyO3/Maturin -> Rust Crate Project -> Maturin -> `import house` just like Python `stdlib`. 

Some inconveniences are coming from Maturin command and Python commands are working on different directories. It is confusing in one console, better do this in two parallel consoles, one for Python and one for Maturin. ![[Console-Python-Maturin202610212226.png]]

Separate your user-defined Python modules with Rust Crates as showed above. `garden` for Python user-defined modules, `house` for Rust Crates.