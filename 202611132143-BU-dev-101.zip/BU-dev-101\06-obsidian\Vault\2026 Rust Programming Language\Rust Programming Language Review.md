---
planner:
  log:
    - start: 2026-10-21 23:38:38
      end: 2026-10-22 01:00:28
tags:
  - TBC
---
2026-10-21, @ZL

## Core Mechanism Of Ownership

**ovo**, ==ownership moves==
==many immutable references== OR ==one and only one mutable reference==
==value outlives reference==

```rust
let x = 5i32;
{
	let y = &x;
}
let addr = std::ptr::addr_of!(y); // panic
println!("{addr}");


let x = String::from("hello");
let y = String::from("world");
let _ = x + y; // why binops +, x is moved but y is immutable ref for String concat?
println!("{x}"); // panic
```

## Core Mechanism of Operator Overloading

##### Explain binops +, x is moved but y is immutable ref for String concatenation

Speaking of  binary operator `+` for `T + T` behaviors, concept of operator overloading behaves similar with C++/C#.
But Rust has operator overloading built on ownership.

```rust
use std::ops::{Add};

struct Foo;
struct Bar;
struct FooBar;
struct BarFoo;

impl Add<Bar> for Foo {
	type Output = FooBar;
	// T + U, T moved, U moved
	fn add(self, rhs: Bar) -> FooBar {
		FooBar
	}
}
impl Add<&Bar> for Foo {
	type Output = FooBar;
	// T + &U, T moved, U immutable ref
	fn add(self, rhs: &Bar) -> FooBar {
		FooBar
	}
}
impl Add<Bar> for &Foo {
	type Output = FooBar;
	// &T + U, T is immutable ref, U is moved
	fn add(self, rhs: Bar) -> FooBar {
		FooBar
	}
}
impl Add<&Bar> for &Foo {
	type Output = FooBar;
	// &T + &U, &T is immutable ref, &U is immutable ref.
	fn add(self, rhs: &Bar) -> FooBar {
		FooBar
	}
}
```

## Core Mechanism for forward ops using `macro_rules!`

Writing one binary operator for one struct is tedious, let along writing all other operators.
Rust have a built-in `macro_rules!` to forward your predefined operator overloading (`T + T`) to all other overloading (`T + &T, &T + T, &T+ &T`).

The concept is rather like `regex`, or `parameterized template` for text stream.
`macro_rules!` is for token stream.

```rust
use std::ops::Add;

#[derive(Clone)]
struct MyNum(i32);
impl Add<Self> for MyNum {
	type Output = MyNum;
	fn add(self, rhs: MyNum) -> MyNum {
		MyNum(self.0 + rhs.0)
	}
}

// macro_rules! macro_name{()=>{};}

macro_rules! forward_add {
    ($T:ty) => {
        impl<'a> std::ops::Add<&'a $T> for $T {
            type Output = $T;
            fn add(self, rhs: &'a $T) -> $T {
                // T + &T -> T + T which implemented above
                // using &T.clone() to avoid recursion operation or to be unique
                self + rhs.clone()
            }
        }
        impl<'a> std::ops::Add<$T> for &'a $T {
            type Output = $T;
            fn add(self, rhs: $T) -> $T {
                // &T + T -> T + T which implemented above
                // using &T.clone() to avoid recursion operation or to be unique
                self.clone() + rhs
            }
        }
        impl<'a, 'b> std::ops::Add<&'b $T> for &'a $T {
            type Output = $T;
            fn add(self, rhs: &'b T) -> $T {
                // &T + &T -> T + T which implemented above
                // using &T.clone() to avoid recursion operation or to be unique
                self.clone() + rhs.clone()
            }
        }
    };
}

forward_add!(MyNum);
```

At this point, why won't ==dive deeper== to forward `Sub`, `Mul` or more?
`macro_rules! macro_name{ ()=>{}; }` is a general template for this situation.

```rust
use std::ops::{Add, Sub, Mul};

#[derive(Clone)]
struct Num(i32);
impl Add for Num {
    type Output = Self;
    // T + t => T is moved, T is moved
    // what if I wanna all T + &T, &T + T, &T + &T
    fn add(self, rhs: Self) -> Self {
        Num(self.0 + rhs.0)
    }
}
impl Sub for Num {
    type Output = Self;
    fn sub(self, rhs: Self) -> Self {
        Num(self.0 - rhs.0)
    }
}
impl Mul for Num {
    type Output = Self;
    fn mul(self, rhs: Self) -> Self {
        Num(self.0 * rhs.0)
    }
}

macro_rules! forward_binops {
  ($T:ty : $($Trait:ident::$method:ident),* $(,)?) => {
     $(
       impl<'a> std::ops::$Trait<&'a $T> for $T {
         type Output = $T;
         fn $method(self, rhs: &'a $T) -> $T {
           std::ops::$Trait::$method(self, rhs.clone())
         }
       }
       impl<'a> std::ops::$Trait<$T> for &'a $T {
         type Output = $T;
         fn $method(self, rhs: $T) -> $T {
           std::ops::$Trait::$method(self.clone(), rhs)
         }
       }
       impl<'a,'b> std::ops::$Trait<&'b $T> for &'a $T {
         type Output = $T;
         fn $method(self, rhs: &'b $T) -> $T {
           std::ops::$Trait::$method(self.clone(), rhs.clone())
         }
       }
     )*
  };
}
forward_binops!(Num : Add::add, Sub::sub, Mul::mul,);
```

Do you notice that ==`lhs self` of `+` is always **moved**==.

So, whenever you do an operation over a variable or pass variables to functions in Rust, you should at least peek operator / function's definition.

Now you know it is like a rabbit hole, [[https://en.wikipedia.org/wiki/Rabbit_Hole_(TV_series)]]
Then I decided that I stop here at this point.

## Core Mechanism of Macro

You can use macro to generate `repeation` codes.
Rust has three kinds of macros

##### declarative macros

```rust

macro_rules! answer {
	() => { 32 };
}

macro_rules! double {
	($n:expr) => { $n * 2 };
}

double!(5 + 10);

macro_rules! greet {
    ($name:expr) => {
        println!("hello, {}!", $name);
    };
    ($name:expr, $greeting:expr) => {
        println!("{}, {}!", $greating, $name);
    };
}

```

##### proc macros
[[https://doc.rust-lang.org/reference/procedural-macros.html]]
- [Function-like macros](https://doc.rust-lang.org/reference/procedural-macros.html#the-proc_macro-attribute) - `custom!(...)`
- [Derive macros](https://doc.rust-lang.org/reference/procedural-macros.html#r-macro.proc.derive) - `#[derive(CustomDerive)]`
- [Attribute macros](https://doc.rust-lang.org/reference/procedural-macros.html#the-proc_macro_attribute-attribute) - `#[CustomAttribute]`

##### built-in macros
```rust
print!()
println!()
eprint!()
eprintln!()
format!()
dbg!()
vec!()
// --snip--
```


## Core Mechanism Of Lifetime 

==You instruct compiler **how long a reference is valid**.==
#### General rules
##### distinct for all
```rust
fn first<'a, 'b>(x: &'a str, y: &'b str) -> &'a str {
	let _ = b;
	a
}
```

##### one for all
```rust
fn longest<'a>(x: &'a str, y: &'a str) -> &'a str {
	if x.len() < y.len() { y } else { x }
}
```

##### self for all
```rust
struct Fahrenheit<'a> {
    lable: &'a str,
    value: f64,
}
impl<'a> Fahrenheit<'a> {
    fn new(x: &'a str, y: f64) -> Self {
        Self { lable: x, value: y }
    }
    fn lable(&'a self) -> &'a str {
        self.lable
    }
    fn value(&'a self) -> f64 {
        self.value
    }
}
```

#### Notes

##### Lifetime subtyping
'<font color="#00b050">a</font> outlives '<font color="#00b050">b</font>

```rust
'a : 'b
```

##### T: '<font color="#00b050">a</font>
T contains references outlive '<font color="#00b050">a</font>, ==not== means T is reference

```rust
fn foo<T:'a>(x: T) {
	todo!()
}
```

##### T: '<font color="#c0504d">static</font>
T is an ==owned type== + any ==static references==

```rust
fn bar<T: 'static>(x: T) {
	todo!()
}
```

##### Explain to yourself

```rust
fn foo<'a, T>(x: &'a T) {
	todo!()
}

fn bar<'a, T:'a>(x: T) {
	todo!()
}

fn fizz<T>(x: &'static T) {
	todo!()
}

fn buzz<T: 'static>(x: T) {
	todo!()
}
```

## Patterns: Rust Idioms

##### Newtype 
```rust
#[allow(dead_code)]
fn process_user_bad(user_id: u64, account_id: u64) {
    println!("Processing user {} in account {}", user_id, account_id);
}

struct User(u64);
impl User {
	fn new(x: u64) -> Self {
		Self(x)
	}
	fn value(&self) -> u64 {
		self.0
	}
}
struct Account(u64);
impl Account {
	fn new(x: u64) -> Self {
		Self(x)
	}
	fn value(&self) -> u64 {
		self.0
	}
}
fn process_user_good(user: User, account: Account) {
	println!("Processing user {} in account {}", user.value, account.value);
}

```

##### Extension

Yup, its concept is just like ==C# extension methods==. 
Let's implements some Python `str` methods for Rust `str` by ZL.
```rust
trait StringExt {
    fn is_blank(&self) -> bool;
    fn make_trans(&self, y: &str) -> Result<HashMap<String, String>, &'static str>;
    fn trasnlate(&self, map: HashMap<String, String>) -> String;
}

impl StringExt for str {
    fn is_blank(&self) -> bool {
        self.trim().is_empty()
    }

    fn make_trans(&self, y: &str) -> Result<HashMap<String, String>, &'static str> {
        if self.is_blank() || y.is_blank() || (self.len() != y.len()) {
            return Err("the first two maketrans arguments must have equal length");
        }
        let mut result = HashMap::new();
        for (k, v) in self.chars().zip(y.chars()) {
            result.insert(k.to_string(), v.to_string());
        }
        Ok(result)
    }

    fn trasnlate(&self, map: HashMap<String, String>) -> String {
        self.chars()
            .map(|c| c.to_string())
            .map(|k| match map.get(&k) {
                Some(v) => v.clone(),
                None => k,
            })
            .collect::<Vec<_>>()
            .join::<_>("")
    }
}

// --snip--
let txt = "Hi Sam!";
let x = "mSa";
let y = "eJo";
let table = x.make_trans(y)?;
assert_eq!(txt.trasnlate(table), "Hi Joe!");
// --snip--

```

##### RAII
[[https://idiomatic-rust-snippets.org/patterns/rust-idioms/raii.html]]
I knew C# `using`, Python `with` for resource management.
But I don't notice it in Rust for now.
<font color="#ff0000">todo!</font>
##### Tyepstate
[[https://idiomatic-rust-snippets.org/patterns/rust-idioms/typestate.html]]
I have no idea about this one at this point. 
<font color="#ff0000">todo!</font>

## Core Mechanism Of Smart Pointers

Smart Pointers are structs that implemented `deref` + `drop` traits.

```rust
use std::ops::{Deref, Drop};

struct Foo;

impl deref for Foo {
	type Target;
	fn deref(&self) -> & Self::Target {
		todo!()
	}
}
impl Drop for Foo {
    fn drop(&mut self) {
        // SAFETY: `self` is pinned till after dropped.
        unsafe { Drop::pin_drop(std::pin::Pin::new_unchecked(self)) }
    }
}
```

##### Box
`Box` mainly used in higher level of abstraction of objects, recursion, like structure of binary trees.

```rust

trait Shape {
	fn area(&self) -> f64;
}

struct Circle(f64);
impl Shape for Circle {
	fn area(&self) -> f64 {
		std::f64::consts::PI * self.0 * self.0
	}
}

struct Rectangle {
	width: f64,
	height: f64,
}
impl Shape for Rectangle {
	fn area(&self) -> f64 {
		self.width * self.height
	}
}

// --snip--
let shapes: Vec<Box<dyn Shape>> = vec![
	Box::new(Circle(2.0)),
	Box::new(Rectangle {
		width: 3.0,
		height: 4.0,
	}),
];

// --snip--

```
##### Rc
`Rc` mainly used in Cons List (LISP concept), shared node.

```rust
// Build a small graph:
//     A
//    / \
//   B   C
//    \ /
//     D

use std::rc::Rc;

struct Node {
	value: i32,
	neighbors: Vec<Rc<Node>>,
}

let d = Rc::new(Node {
	value: 1,
	neighbors: vec![],
});
let b = Rc::new(Node {
	value: 2,
	neighbors: vec![Rc::clone(&d)],
});
let c = Rc::new(Node {
	value: 3,
	neighbors: vec![Rc::clone(&d)],
});
let a = Rc::new(Node {
	value: 4,
	neighbors: vec![Rc::clone(&b), Rc::clone(&c)],
});

let n = Rc::strong_count(&d);
```

##### Arc
`Arc` which implemented `Send` trait, mainly used in thread to exchange values.

```rust
use std::sync::Arc;

struct Truck {
	capacity: u32,
}

let (a, b, c) = (
	Arc::new(Truck { capacity: 1 }),
	Arc::new(Truck { capacity: 2 }),
	Arc::new(Truck { capacity: 3 }),
);
let thread = std::thread::spawn(move || {
	let facility_one = vec![Arc::clone(&a), Arc::clone(&b)];
	let facility_two = vec![Arc::clone(&b), Arc::clone(&c)];
	(facility_one, facility_two)
});
let (facility_one, facility_two) = thread.join().unwrap();

let b = Arc::clone(&facility_one[1]);
let n = Arc::strong_count(&b);

```