2026-10-21

## `uv` workflow

using the following commands to create your Python project with `uv`

1. install `uv` on your machine [[https://docs.astral.sh/uv/getting-started/installation/]]
2.  `uv` **init** {project_name}
3.  **cd** {project_name}
4. `uv` **run** {project_name}
5. `uv` **add** `maturin`![[Command-uv-add-maturin20261021204931.png]]

