2026-10-21

## PyO3/Maturin 
they are powerful tools that enable developers to create Python bindings for Rust code, allowing for high-performance applications that leverage Rust's speed and Python's ease of use. see more [[https://github.com/PyO3/maturin]]

## Use Maturin

1. cd {package_name}
2. `maturin` **init** then select **PyO3** with up/down key in this case
3. open **lib.rs** in your favorite editor then write your function following the pattern of sample code given by **PyO3![[Code-PyO3-Maturin202610212107.png]]**
4. **maturin** develop --release. it is for **fast local development** — it builds your PyO3/Cargo crate in debug mode and installs it directly into your current virtualenv so you can run and test it without rebuilding after each change.
5. **maturin** build --release is for **producing an optimized wheel** that can be installed via `pip` or published to PyPI.