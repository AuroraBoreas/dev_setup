---
planner:
  log:
    - start: 2026-11-03 14:36:00
      end: 2026-11-03 15:57:13
---
## Start with Django

It is simple like this.
```powershell
mkdir django-web
cd django-web
python -m venv .venv
.venv\Scripts\activate
pip install django gunicorn
pip freeze > requirements.txt
```

But there is a pitfall here about `requirements.txt`. Python package `psycopg2 != psycopg[binary]`
Read more here https://www.psycopg.org/psycopg3/docs/basic/install.html

![[python-dependencies-20261103.png|374]]

You have to manually add `psycopg[binary]` to `requirements.txt` 
![[python-dependecies-psycopg-20261103150012.png]]

Continue your `Django` project
```powershell
# ...
mkdir src
django-admin startsprojects myapp . 
```

And here is your `Django` project structure
![[django-project-struct-20261103151851.png]]

Then create `Dockerfile` family
```powershell
New-Item .dockerignore -ItemType File
New-Item Dockerfile -ItemType File
New-Item Compose.yml -ItemType File
```

We skip `.dockerignore`
We go open `Dockerfile` and write some commands.
```Dockerfile
FROM python:3.15.2-slim-trixie
WORKDIR /app
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1

COPY ./requirements.txt /app
RUN pip install -r requirements.txt

COPY ./src .

CMD ["gunicorn", "myapp.wsgi:application", "--bind", "0.0.0.0:8000"]

# CMD [ "./entrypoint.sh" ]
```
Because You can have one and only one `CMD` in your `Dockerfile`, it is quite limited when you want to do more operations like `python manage.py makemigrations`, `python manage.py migrate` etc. `entrypoint.sh` comes in to chat.

Create an `entrypoint.sh` under `/src`, and then put your operations here. Note that `shebang` must always be on the first line of `entrypoint.sh`
```entrypoint.sh
#!/bin/sh

python manage.py migrate --no-input
gunicorn myapp.wsgi:application --bind 0.0.0.0:8000
```
![[django-project-dockerfile-family-20261103152144.png]]

Then we modify `CMD` in `Dockerfile`
```Dockerfile
# ...
# CMD ["gunicorn", "myapp.wsgi:application", "--bind", "0.0.0.0:8000"]
CMD [ "./entrypoint.sh" ]
```

And then we go `Compose.yml`
```Compose.yml
services:
  api:
    container_name: django_container
    build: .
    restart: unless-stopped
    ports:
      - "8000:8000"
    volumes:
      - ./src:/app
```

We stop `Django` part here, go to `Postgres` next.

## Postgres

Only thing we need is add `Postgres` service into `Compose.yml`
```Compose.yml
  # ...
  db:
    container_name: postgres_container
    image: postgres:alpine
    restart: always
    environment:
      POSTGRES_USER: admin
      POSTGRES_PASSWORD: admin
      POSTGRES_DB: test_db
    ports:
      - "5432:5432"
```

We want to wire `Django` up with `Postgres` database.
We observe `Django settings.py` shares `environment variables` with `postgres`.
![[django-postgres-env-20261103.png|443]]

So we create a `.env` file and store the shared info.
```.env
# postgres && django
POSTGRES_USER=admin
POSTGRES_PASSWORD=admin
POSTGRES_DB=test_db
DB_HOST=db
DB_PORT=5432
```
Finally, `Docker Compose` will verify the connection between `Django` and `Postgres` database.
`Django` need `os` module to read environment variables from `.env`
`Compose` by default, can read environment variables from `.env`

```Compose.yml
services:
  api:
    container_name: django_container
    build: .
    restart: unless-stopped
    ports:
      - "8000:8000"
    volumes:
      - ./src:/app
    env_file:
      - .env
    depends_on:
      db:
        condition: service_healthy
        restart: true
  db:
    container_name: postgres_container
    image: postgres:alpine
    restart: always
    environment:
      POSTGRES_USER: ${POSTGRES_USER}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      POSTGRES_DB: ${POSTGRES_DB}
    ports:
      - "5432:5432"
    env_file:
      - .env
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER} -d ${POSTGRES_DB}"]
      interval: 1m30s
      timeout: 30s
      retries: 5
      start_period: 30s
```

We build our services.
```powershell
docker compose up --build -d
```

## Q&A

How to do `makemigrations` inside of `django_container`?
```powershell
docker exec django_container python manage.py makemigrations
docker exec django_container python manage.py migrate
```

It is quite similar with 
```powershell
docker exec -it <CONTAINER ID> /bin/sh 
```
