# $host.ui.RawUI.WindowTitle = "🐱‍🚀🚀🌔"

# TOC [stable(since="0.1.0")]
# ---------------------------------------------------------------
# oh-my-posh
# Vite+
# Python Make
# C/C++ Make
# DevEnvBackup Make
# Config Make
# Utils Make
# Postgres Make
# Rust Make

$MyAlias = @{
  ve      = 'Create-Python-Venv'
  source  = 'Activate-Python-Venv'
  freeze  = 'Freeze-Python-Dependencies'
  ndi     = 'New-DjangoInfra'
  ndc     = 'New-DjangoCompose'
  tdd     = 'Generate-TestData-Django'
  rad     = 'Generate-RestApi-Django'
  bu      = 'Backup-DevEnv-And-ObsidianProjects'
  grcc    = 'Get-Rust-Combinator-Cheatsheet'
  wls     = 'Watch-Lua-Script'
  gdf     = 'Get-Dockfire-Family'
  gpcs    = 'Get-Postgres-ConnectionString'
  iawc    = 'Invoke-Api-With-Curl'
  gcw     = 'Get-Cargo-Workspace'
  rcw     = 'Run-Cargo-Watch'
  rwc     = 'Run-WatchExec-Cargo'
  nri     = 'New-RustInfra'
  nrc     = 'New-RustCompose'
  mmr     = 'MakeMigrations-Rust'
  mr      = 'Migrate-Rust'
  htr     = 'Generate-HttpTests-Rust'
}

Set-Alias ve     Create-Python-Venv
Set-Alias source Activate-Python-Venv
Set-Alias freeze Freeze-Python-Dependencies
Set-Alias ndi    New-DjangoInfra
Set-Alias ndc    New-DjangoCompose
Set-Alias tdd    Generate-TestData-Django
Set-Alias rad    Generate-RestApi-Django
Set-Alias bu     Backup-DevEnv-And-ObsidianProjects
Set-Alias grcc   Get-Rust-Combinator-Cheatsheet
Set-Alias wls    Watch-Lua-Script
Set-Alias gdf    Get-Dockfire-Family
Set-Alias gpcs   Get-Postgres-ConnectionString
Set-Alias iawc   Invoke-Api-With-Curl
Set-Alias gcw    Get-Cargo-Workspace
Set-Alias rcw    Run-Cargo-Watch
Set-Alias rwc    Run-WatchExec-Cargo
Set-Alias nri    New-RustInfra
Set-Alias nrc    New-RustCompose
Set-Alias mmr    MakeMigrations-Rust
Set-Alias mr     Migrate-Rust
Set-Alias htr    Generate-HttpTests-Rust

# oh-my-posh scheme
# ---------------------------------------------------------------
& ([ScriptBlock]::Create((oh-my-posh init pwsh --config "$env:POSH_THEMES_PATH\clean-detailed.omp.json" --print) -join "`n"))

# Vite+ Make [stable(since="0.1.0")]
# ---------------------------------------------------------------
. 'C:\Users\Attuned\AppData\Roaming\vite-plus\env.ps1'

# Python Make. [deprecated(msg="using uv instead")][stable(since="0.1.0")]
# ---------------------------------------------------------------
function Create-Python-Venv {
  param(
    [Parameter(Mandatory, HelpMessage='project name')]
    [String]$projectName
  )
  if (-not (Test-Path $projectName)) {
    New-Item $projectName -ItemType Directory | Out-Null
    Set-Location $projectName
    python -m venv .venv
    Write-Host "project created at: $projectName" -ForegroundColor Green
  } else {
    Write-Host "failed to create project: $projectName" -ForegroundColor -Red
  }
}

function Activate-Python-Venv {
  if ([System.Environment]::OSVersion.VersionString -like '*Unix*') {source .venv/bin/activate} else {.venv\scripts\activate}
}

function Freeze-Python-Dependencies {pip freeze > requirements.txt}

function Generate-SecretKey {
  python -c "import secrets; print(secrets.token_urlsafe(50))"
}

function New-DjangoInfra {
  param(
    [Parameter(Mandatory, HelpMessage='project name from django-admin startproject')]
    [string]$appName
  )
  if (-not (Test-Path "./.venv")) { return }

  Initialize-DjangoSettings $appName
  Get-DjangoDependencies
}

function New-DjangoCompose {
  param(
    [Parameter(Mandatory, HelpMessage='appname')]
    [string]$appName,
    [Parameter(Mandatory,HelpMessage='service:port from Compose.yml')]
    [string]$serverAddr
  )
  if (-not (Test-Path "./.venv")) { return }

  New-DotEnv-Django $appName
  New-Config-Nginx $serverAddr
  Get-Dockfire-Family
}

function New-DotEnv-Django {
  param(
    [Parameter(Mandatory, HelpMessage='appname')]
    [string]$appName
  )
  if (-not (Test-Path "./.venv")) { return }
  $sk = python -c "import secrets; print(secrets.token_urlsafe(50))"

@"
DJANGO_ENV=dev
ALLOWED_HOSTS=localhost,127.0.0.1
SECRET_KEY=$sk

REDIS_URL=redis://127.0.0.1:6379

DATABASE_URL=postgres://admin:admin@localhost:5432/${appName}

POSTGRES_USER=admin
POSTGRES_PASSWORD=admin
POSTGRES_DB=${appName}
DB_HOST=db
DB_PORT=5432
"@ | Set-Content '.env' -Encoding UTF8
}

function Get-DjangoDependencies {
  param([string]$dst=".")
  if (-not (Test-Path "$dst/.venv")) {
    return
  }

@"
django
djangorestframework
django-environ
faker
gunicorn
psycopg[binary]
"@ | Set-Content 'requirements.txt' -Encoding UTF8
}

function Initialize-DjangoSettings {
  param(
    [Parameter(Mandatory, HelpMessage='project name from django-admin startproject')]
    [string]$Name
  )
  if (-not (Test-Path "./.venv")) {
    Write-Host ".venv NotFound" -ForegroundColor Red
    return 
  }
  $Name = $Name.ToLower()
  $appDir = Join-Path $PWD "src/${Name}"
  if (-not (Test-Path $appDir)) { 
    Write-Host "$appDir NotFound" -ForegroundColor Red
    return 
  }

  $settingsDir = Join-Path $appDir "settings"
  # Remove default settings.py if it exists
  $defaultSettings = Join-Path $appDir "settings.py"
  if (Test-Path $defaultSettings) {
    Remove-Item $defaultSettings
    Write-Host "Removed default settings.py" -ForegroundColor Yellow
  }

  if (-not (Test-Path $settingsDir)) {
    New-Item -ItemType Directory -Path $settingsDir -Force | Out-Null
  }

# __init__.py
@"
import os

env = os.getenv("DJANGO_ENV", "dev")
if env == "prod":
    from .prod import *
else:
    from .dev import *
"@ | Set-Content -Path (Join-Path $settingsDir "__init__.py") -Encoding UTF8

# base.py
@"
from pathlib import Path
import environ

# src/
BASE_DIR = Path(__file__).resolve().parent.parent.parent
env = environ.Env()
environ.Env.read_env(BASE_DIR.parent / ".env")

SECRET_KEY = env("SECRET_KEY")
DEBUG = False
ALLOWED_HOSTS = []

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "${Name}.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "${Name}.wsgi.application"
ASGI_APPLICATION = "${Name}.asgi.application"

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
"@ | Set-Content -Path (Join-Path $settingsDir "base.py") -Encoding UTF8

# dev.py
@"
import os
from .base import *

DEBUG = True
ALLOWED_HOSTS = ["*"]

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.environ["POSTGRES_DB"],
        "USER": os.environ["POSTGRES_USER"],
        "PASSWORD": os.environ["POSTGRES_PASSWORD"],
        "HOST": os.environ["DB_HOST"],
        "PORT": os.environ["DB_PORT"],
    }
}
"@ | Set-Content -Path (Join-Path $settingsDir "dev.py") -Encoding UTF8

# prod.py
@"
from .base import *

DEBUG = False
ALLOWED_HOSTS = env.list("ALLOWED_HOSTS")

DATABASES = {"default": env.db()}

SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_HSTS_SECONDS = 31536000
"@ | Set-Content -Path (Join-Path $settingsDir "prod.py") -Encoding UTF8

# entrypoint
  $script = 
@"
#!/bin/sh

python manage.py migrate --no-input
python manage.py collectstatic --no-input

gunicorn ${Name}.wsgi:application --bind 0.0.0.0:8000 --workers 4
"@ -replace "`r`n", "`n"

  New-Item -Path (Join-Path "$pwd/src" "entrypoint.sh") -ItemType File -Value $script -Force | Out-Null

  Write-Host "src/${Name}/settings/ created:" -ForegroundColor Green
  Get-ChildItem $settingsDir | ForEach-Object { Write-Host "  $($_.Name)" }
}

function Generate-RestApi-Django {
  if (-not (Test-Path "./.venv")) { return }
  $excluded = @('staticfiles','static','templates','median','*app','config','src')
  $features = Get-ChildItem -Path './src' -Attributes Directory -Exclude $excluded -Name
  foreach($e in $features) { Generate-RestApi-DjangoService $e }

  Write-RouterUrls-DjangoService $features
}

function Write-RouterUrls-DjangoService {
  param(
    [Parameter(Mandatory)][string[]]$features
  )

  $urlsFile = "./src/config/urls.py"

  $restBlock =
@"
from rest_framework.routers import DefaultRouter
router = DefaultRouter()

"@

  if (-not (Select-String -Path $urlsFile -Pattern "rest_framework" -Quiet)) {
    Insert-FileLine -Path $urlsFile -Index 19 -Content $restBlock
  }

  $imports = $features | ForEach-Object {
    $c = $_.ToUpper()[0] + $_.Substring(1)
    $class = "import ${c}ViewSet"
    if (-not (Select-String -Path $urlsFile -Pattern $class -Quiet)) {
      "from $_.views import ${c}ViewSet"
    }
  }

  $registers = $features | ForEach-Object {
    $c = $_.ToUpper()[0] + $_.Substring(1)
    $class = "${c}ViewSet, basename="
    if (-not (Select-String -Path $urlsFile -Pattern $class -Quiet)) {
      "router.register(`"${_}s`", ${c}ViewSet, basename=`"${_}`")"
    }
  }

  if ([string]::IsNullOrEmpty($imports) -or [string]::IsNullOrEmpty($registers)) {
    return
  } else {
    $block =
@"

$(($imports -join "`n"))
$(($registers -join "`n"))

"@

    Insert-FileLine -Path $urlsFile -Index 21 -Content $block
  }

  $includePath = "router.urls"
  if (-not (Select-String -Path $urlsFile -Pattern $includePath -Quiet)) {

    $insertPath =
@"
    path("api/", include(router.urls)),
"@

    Insert-FileLine -Path $urlsFile -Index ((Get-Content $urlsFile).Count - 1) -Content $insertPath
  }
}

function Insert-FileLine {
  param(
    [string]$Path,
    [int]$Index,
    [string]$Content
  )
  $lines = [System.Collections.ArrayList](Get-Content $Path)
  $lines.Insert($Index, $Content)
  $lines | Set-Content $Path
}

function Generate-RestApi-DjangoService {
  param(
    [Parameter(Mandatory, HelpMessage='feature name')]
    [string]$featureName
  )

  if (-not (Test-Path './.venv')) { return }

  $featureName = $featureName.ToLower()
  $parentDir = Join-Path './src' $featureName
  if (-not (Test-Path $parentDir)) { 
    Write-Host "$featureName NotFound" -ForegroundColor Red
    return 
  }
  $Name = $featureName.Substring(0,1).ToUpper() + $featureName.Substring(1)

@"
from rest_framework import serializers

from .models import ${Name}


class ${Name}Serializer(serializers.ModelSerializer):
    class Meta:
        model = ${Name}
        fields = "__all__"
"@ | Set-Content -Path "$parentDir/serializers.py" -Encoding UTF8 -Force

@"
"@ | Set-Content -Path "$parentDir/urls.py" -Encoding UTF8 -Force

  $viewsFile = "$parentDir/views.py"
  $class = "class ${Name}ViewSet"
  # idempotency guard
  if (Select-String -Path $viewsFile -Pattern $class -Quiet) {
    Write-Host "skip: $Name already exists" -ForegroundColor Yellow
    return
  }
@"
from rest_framework import viewsets

from .models import ${Name}
from .serializers import ${Name}Serializer


class ${Name}ViewSet(viewsets.ModelViewSet):
    queryset = ${Name}.objects.all()
    serializer_class = ${Name}Serializer
"@ | Add-Content -Path $viewsFile -Encoding UTF8
}

function Generate-TestData-Django {
  if (-not (Test-Path "./.venv")) { return }
  $excluded = @('staticfiles','static','templates','median','*app','config')
  $features = Get-ChildItem -Path './src' -Attributes Directory -Exclude $excluded -Name
  foreach($e in $features) { Generate-TestData-DjangoService $e }
}

function Generate-TestData-DjangoService {
  param(
    [Parameter(Mandatory, HelpMessage='feature name')]
    [string]$featureName
  )

  if (-not (Test-Path './.venv')) { return }

  $featureName = $featureName.ToLower()
  $parentDir = Join-Path './src' $featureName
  if (-not (Test-Path $parentDir)) { 
    Write-Host "$featureName NotFound" -ForegroundColor Red
    return 
  }
  $Name = $featureName.Substring(0,1).ToUpper() + $featureName.Substring(1)
  $content =
@"
import random

import faker
from django.core.management.base import BaseCommand

from $($Name.ToLower()).models import $Name


class Command(BaseCommand):
    help = "Populate ModelName table with sample data"

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "count", type=int, help="Number of test data instances to create"
        )

    def handle(self, *args, **kwargs) -> None:
        self.stdout.write(self.style.NOTICE("Data loading started"))
        count = kwargs["count"]
        if count <= 0:
            self.stdout.write(self.style.WARNING("count must be a positive integer"))
            return
        fake = faker.Faker()
        n = count
        for _ in range(n):
            _ = $Name.objects.get_or_create(
                name=fake.name(),
                product_code=fake.lexify(text="???").upper() + fake.numerify(text="##"),
                title=fake.sentence(random.randint(4, 10)),
                description=fake.paragraph(),
            )[0]
        self.stdout.write(self.style.SUCCESS("Data loaded successfully"))
"@

  New-Item -Path "$parentDir/management/commands/load_${featureName}s.py" -ItemType File -Value $content -Force | Out-Null
}

# C/C++ Make, 20240710
# ---------------------------------------------------------------
function Get-Preprocess {param([string]$src='main.c') gcc -E $src}
function Get-Assembly {param([string]$src='main.c') gcc -S $src}
function Get-MachineCode {param([string]$src='main.c') gcc -c $src}
function Get-Executable {param([string]$src='main.c', [string]$dst='a') gcc $src -o $dst}
function Get-DumpTreeGraph {param([string]$src='main.c') gcc -fdump-tree-all-graph -g $src}
function Get-ObjDump {param([string]$src='main.o') objdump $src}
function Get-ld {param([string]$src) ld $src}


# DevEnvBackup [deprecated(msg="in 2025. macpro dead")][stable(since="0.1.0")]
# ---------------------------------------------------------------
function Sync-VSCode-Zed-RustCodeSnippet{
  param(
    [string]$srcDir='~/AppData/Roaming/Code/User/snippets',
    [string]$dstDir='~/AppData/Roaming/Zed/snippets'
  )
  if (-not ((Test-Path $srcDir) -and (Test-Path $dstDir))) { return }
  $rustJson = "rust.json"
  $tomlJson = "toml.json"
  $srcFile = "$srcDir/$rustJson"
  if (Test-Path $srcFile) {Copy-Item -Path $srcFile -Destination "$dstDir/$rustJson" -Force}
  $srcFile = "$srcDir/$tomlJson"
  if (Test-Path $srcFile) {Copy-Item -Path $srcFile -Destination "$dstDir/$tomlJson" -Force}
}

function Backup-Dev-Env-Settings {
  $root = '~'
  $buDir="$root\BU-dev-101\"
  If (-not (Test-Path $buDir)) {mkdir $buDir | Out-Null}

  # --- vscode ---
  $dst="$buDir\01-vscode"
  If (-not (Test-Path $dst)) {mkdir $dst | Out-Null}
  $editorName = 'Code'
  $srcPaths=(
    "$root\AppData\Roaming\$editorName\User\keybindings.json",
    "$root\AppData\Roaming\$editorName\User\settings.json",
    "$root\AppData\Roaming\$editorName\User\snippets\"
  )
  ForEach($SrcPath in $srcPaths) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}
  $extensions = code --list-extensions
  $extensions | Out-File -FilePath "$dst\vscode-extensions.txt" -Encoding utf8

  # --- windows terminal ---
  $dst="$buDir\02-windows-terminal\"
  If (-not (Test-Path $dst)) {mkdir $dst | Out-Null}
  $srcPaths=(
    "$root\AppData\Local\Packages\Microsoft.WindowsTerminal_8wekyb3d8bbwe\LocalState\settings.json",
    "$root\Documents\WindowsPowerShell\Microsoft.PowerShell_profile.ps1"
  )
  ForEach($SrcPath in $srcPaths) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}

  # --- blender ---
  # $dst="$buDir\05-utilities\MyPkg\blender\preferences\user_config"
  # If (-not (Test-Path $dst)) {mkdir $dst}
  # $SrcPath="$root\AppData\Roaming\Blender Foundation\Blender\4.1\config\userpref.blend"
  # If (Test-Path $SrcPath) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}

  # --- vs ---
  $dst="$buDir\03-vs"
  If (-not (Test-Path $dst)) {mkdir $dst | Out-Null}
  $SrcPath="$root\Documents\Visual Studio 2022\Code Snippets"
  If (Test-Path $SrcPath) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}
  $SrcPath="C:\ProgramE\Program\Microsoft Visual Studio\Common7\IDE\VC\Snippets"
  If (Test-Path $SrcPath) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}

  # --- idea ---
  # manually bu

  # --- zed ---
  $dst="$buDir\05-zed"
  If (-not (Test-Path $dst)) {mkdir $dst | Out-Null}
  $editorName = 'Zed'
  $srcPaths=(
    "$root\AppData\Roaming\$editorName\keymap.json",
    "$root\AppData\Roaming\$editorName\settings.json",
    "$root\AppData\Roaming\$editorName\snippets\"
  )
  ForEach($srcPath in $srcPaths) {Copy-Item -Path $srcPath -Destination $dst -Recurse -Force}

  # --- toolkit ---
  $dst=$buDir
  $folderPath='C:\ProgramE\Program\'
  If (Test-Path $folderPath) {
    $subfolders = Get-ChildItem -Path $folderPath -Directory
    $subfolders | Select-Object Name | Export-Csv -Path "$dst\devEnv.csv" -NoTypeInformation
  }

  $src=$buDir
  $timeStamp = Get-Date -Format 'yyyyMMddHHmm'

  Set-Location $root
  $dstArchive="$pwd\$timeStamp-BU-dev-101.zip"
  Compress-Archive -Path $src -DestinationPath $dstArchive -Force
  Start-Process -FilePath explorer.exe -ArgumentList "/select,`"$dstArchive`""

}

function Update-VSCode-UserSnippet {
  param([string]$path="$root\BU-dev-101\01-vscode\snippets\")
  $dst="$root\AppData\Roaming\Code\User"
  if (Test-Path $dst) {
    Copy-Item -Path $path -Destination $dst -Force -Recurse
  }
}

function Backup-Obsidian-Projects {
  $root = '~'
  $buDir="$root\BU-Obsidian-Projects\"
  If (-not (Test-Path $buDir)) {mkdir $buDir | Out-Null}

  # --- obsidian ---
  $dst="$buDir\01-obsidian"
  If (-not (Test-Path $dst)) {mkdir $dst | Out-Null}
  $srcPath='~\ObsidianProjects\Vault'
  If (Test-Path $SrcPath) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}
  $excluded="$dst\Vault\.obsidian"
  If (Test-Path $excluded) {Remove-Item -force -recurse $excluded}

  $src=$buDir
  $timeStamp = Get-Date -Format 'yyyyMMddHHmm'
  $dst="$root\$timeStamp-BU-Obsidian-Projects.zip"
  Compress-Archive -Path $src -DestinationPath $dst -Force
}

function Backup-DevEnv-And-ObsidianProjects {
  param([bool]$obs=$false)
  Sync-VSCode-Zed-RustCodeSnippet
  Backup-Dev-Env-Settings
  if ($obs) { Backup-Obsidian-Projects }
}

# Config Make [stable(since="0.1.0")]
# ---------------------------------------------------------------
function New-Config-Nginx {
  param(
    [Parameter(Mandatory,HelpMessage='service:port from Compose.yml')]
    [string]$serverAddr
  )
  if (-not ($serverAddr -match ':\d{4}')) {
    Write-Host 'serverAddr must be like api:8080' -ForegroundColor Red
    return
  }
  $cfg =
@"
limit_req_zone `$binary_remote_addr zone=api:10m rate=10r/s;
limit_conn_zone `$binary_remote_addr zone=conn_per_ip:10m;
proxy_cache_path /var/cache/nginx/cache levels=1:2 keys_zone=app_cache:10m max_size=1g inactive=60m use_temp_path=off;

upstream app_backend {
  server ${serverAddr};
}

server {
  listen 80;
  server_name _;

  # --- Connection limit: max 20 concurrent connections per IP ---
  limit_conn conn_per_ip 20;
  limit_conn_status 429;

  # --- Static files: cached ---
  location /static/ {
    alias /app/staticfiles/;
    proxy_cache app_cache;
    proxy_cache_valid 200 1h;
    proxy_cache_methods GET;
    add_header Cache-Control "public";
  }

  # --- API: no cache (Redis handles it) ---
  location / {
    # --- Rate limit: 10 req/s, burst 20 ---
    limit_req zone=api burst=20 nodelay;
    limit_req_status 429;

    proxy_pass http://app_backend;
    proxy_set_header Host `$host;
    proxy_set_header X-Real-IP `$remote_addr;
    proxy_set_header X-Forwarded-For `$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto `$scheme;
  }
}
"@

  New-Item -Path "./nginx.conf" -ItemType File -Value $cfg -Force | Out-Null
}

function New-Config-Caddy {
  param(
    [Parameter(Mandatory,HelpMessage='service:port from Compose.yml')]
    [string]$serverAddr
  )
  if (-not ($serverAddr -match ':\d{4}')) {
    Write-Host 'serverAddr must be like api:8080' -ForegroundColor Red
    return
  }
  $cfg =
@"
http://localhost {
  reverse_proxy $serverAddr
}
"@

  New-Item -Path "./Caddyfile" -ItemType File -Value $cfg -Force | Out-Null
}

function Get-PortUsage {
  netstat -ano | select-string "80"
}

# Utils Make [stable(since="0.1.0")]
# ---------------------------------------------------------------
function Update-Powershell-PackageManager {
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

  $names = @('PowerShellGet', 'PackageManagement', 'Microsoft.PowerShell.PSResourceGet')
  Get-Module -Name $names -ListAvailable
  Find-Module -Name $names -Repository PSGallery

  Install-Module PowerShellGet -Repository PSGallery -Force -AllowClobber
  Install-Module Microsoft.PowerShell.PSResourceGet -Repository PSGallery
}

function Watch-Lua-Script {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory, HelpMessage='lua script path')]
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [string]$path
  )
  $path = (Resolve-Path $path).Path
  $directory = Split-Path -Path $path -Parent
  $filename = Split-Path -Path $path -Leaf

  $watcher = New-Object System.IO.FileSystemWatcher
  $watcher.Path = $directory
  $watcher.Filter = $filename
  $watcher.NotifyFilter = [System.IO.NotifyFilters]::LastWrite -bor [System.IO.NotifyFilters]::FileName -bor [System.IO.NotifyFilters]::CreationTime
  $watcher.IncludeSubdirectories = $false

  $state = [hashtable]::Synchronized(@{ LastRun = [datetime]::MinValue })
  $msgData = @{ Path = $path; Debounce = 2; State = $state }

  $action = {
    $m = $Event.MessageData
    $now = Get-Date
    if (($now - $m.State.LastRun).TotalSeconds -lt $m.Debounce) { return }
    $m.State.LastRun = $now

    $evt = $Event.SourceEventArgs
    $msg = "$(Get-Date -Format 'HH:mm:ss') $($evt.ChangeType) $($evt.FullPath)"
    #$msg | Out-File ~\watch.log -Append
    Write-Host $msg -ForegroundColor Cyan
    try {
      & lua $m.Path 2>&1 | Out-Host
    }
    catch {
      #$_ | Out-File ~\watch.log -Append
      Write-Host $_ -ForegroundColor Red
    }
  }

  $s1 = Register-ObjectEvent -InputObject $watcher -EventName Changed -MessageData $msgData -Action $action
  $s2 = Register-ObjectEvent -InputObject $watcher -EventName Created -MessageData $msgData -Action $action
  $s3 = Register-ObjectEvent -InputObject $watcher -EventName Renamed -MessageData $msgData -Action $action
  $watcher.EnableRaisingEvents = $true

  Write-Host "Watching $path (subs: $($s1.Id),$($s2.Id),$($s3.Id))" -ForegroundColor Green
  #Write-Host "Press Ctrl+C to stop..." -ForegroundColor Yellow

  try { while ($true) { Start-Sleep -Seconds 1 } }
  finally {
    $watcher.EnableRaisingEvents = $false
    $watcher.Dispose()
    Unregister-Event -SubscriptionId $s1.Id -ErrorAction SilentlyContinue
    Unregister-Event -SubscriptionId $s2.Id -ErrorAction SilentlyContinue
    Unregister-Event -SubscriptionId $s3.Id -ErrorAction SilentlyContinue
  }
}

function Get-Dockfire-Family {
  param(
    [String[]]$fileNames=@('.dockerignore','Dockerfile','Compose.yml')
  )
  $filenames.foreach({if (-not (test-path $_)) {new-item -Path $_ -ItemType File | Out-Null}})
}

function Get-Rust-Combinator-Cheatsheet{
  param(
    [ValidateSet('c','i','l','t','awjf','awrs','pt','ro')]
    [String]$key='c'
  )
  $combinators=@(
    [pscustomobject]@{Purpose='Transform success value';Option='map';Result='map'}
    [pscustomobject]@{Purpose='Transform with fallback';Option='map_or / map_or_else';Result='map_or / map_or_else'}
    [pscustomobject]@{Purpose='Chain fallible ops (flatten)';Option='and_then';Result='and_then'}
    [pscustomobject]@{Purpose='Recover on failure';Option='or / or_else';Result='or / or_else'}
    [pscustomobject]@{Purpose='Keep based on predicate';Option='filter';Result='-(use and_then)'}
    [pscustomobject]@{Purpose='Convert to Result';Option='ok_or / ok_or_else';Result='-'}
    [pscustomobject]@{Purpose='Peek for logging';Option='inspect';Result='inspect / inspect_err'}
    [pscustomobject]@{Purpose='Combine two';Option='zip, and, or';Result='and, or'}
    [pscustomobject]@{Purpose='Early return on failure';Option='?';Result='?'}
  )
  $iterators=@(
    [pscustomobject]@{Method='iter()';Receiver='&self';Yields='&T';Ownership='Borrow immutable'}
    [pscustomobject]@{Method='iter_mut()';Receiver='&mut self';Yields='&mut T';Ownership='Borrow mutable'}
    [pscustomobject]@{Method='into_iter()';Receiver='self';Yields='T';Ownership='moved, to owned'}
  )
  $lifetime=@(
    [pscustomobject]@{Concept='distinc for all';Example='fn first<''a, ''b>(x: &''a str, y: &''b str) -> &''a str {..}'}
    [pscustomobject]@{Concept='one for all';Example='fn longest<''a>(x: &''a str, y: &''a str) -> &''a str {..}'}
    [pscustomobject]@{Concept='self for all';Example='struct Fahrenheit<''a> {lable: &''a str,} impl<''a> Fahrenheit<''a> {fn lable(&''a self) -> &''a str {..}}'}
    [pscustomobject]@{Concept='''a:''b';Example='''a outlives ''b'}
    [pscustomobject]@{Concept='T:''a';Example='T contains references outlives ''a, not means T is reference'}
    [pscustomobject]@{Concept='T:''static';Example='T is an owned type + any static reference'}
  )
  $trait=@(
    [pscustomobject]@{Method='trait Tr: SuperTrait{..}';Result='bound user-defined trait'}
    [pscustomobject]@{Method='trait Tr<T>{..}';Result='generic user-defined trait, blanket impl'}
  )
  $actixwebJF=@(
    [pscustomobject]@{Name='web::Json<T>';ContentType='application/json';CurlFlag='-d ''{"k":"v"}''(pwsh[\"])';BodyFormat='{"name":"alice","age":42}';FileContent='-d "@payload.json"'}
    [pscustomobject]@{Name='web::Form<T>';ContentType='application/x-www-form-urlencoded';CurlFlag='-d "k=v&k2=v2"';BodyFormat='name=alice&age=42';FileContent='-d "@payload.txt"'}
  )
  $actixwebRS=@(
    [pscustomobject]@{Name='web::resource("/x")';Concept='One path, multiple methods';HandleRequest='Yes(via its routes)';CanContain='.route(),.name(),.guard()';Example='web::resource("/users/{id}").route(web::get().to(get_user)).route(web::delete().to(delete_user))'}
    [pscustomobject]@{Name='web::scope("/x")';Concept='A prefix namespace';HandleRequest='No(delegates to children)';CanContain='.route(),.service(resource),service(scope)';Example='web::scope("/api").route("/users",web::get().to(list))'}
  )
  $codeSnippetPlaceholderTramsform=@(
    [pscustomobject]@{Syntax='${1/(.*)/${1:/upcase}/}';Result='HELLO'}
    [pscustomobject]@{Syntax='${1/(.*)/${1:/downcase}/}';Result='hello'}
    [pscustomobject]@{Syntax='${1/(.*)/${1:/capitalize}/}';Result='Hello'}
    [pscustomobject]@{Syntax='${1/(.*)/${1:/camelcase}/}';Result='helloWorld (from hello_world)'}
    [pscustomobject]@{Syntax='${1/(.*)/${1:/pascalcase}/}';Result='HelloWorld (from hello_world)'}
  )
  $routers=@(
    [pscustomobject]@{Name='XGPON';IP_Addr='192.168.1.1';Admin='user';Pass='j8#nxza3';WIFI='CMCC-4Fj9';WPASS='mmkfgwph'}
    [pscustomobject]@{Name='RAX3000Z';IP_Addr='192.168.10.1';Admin='user';Pass='b7e4p@zu';WIFI='CMCC-aern-5G';WPASS='b7e4p2zu'}
  )

  $labels=[ordered]@{c='combinators';i='iterators';l='lifetime';t='trait';awJF='actixweb JF';awRS='actixweb RS';pt='CodeSnippet Placeholder Transform';ro='Routers'}
  $map=[ordered]@{c=$combinators;i=$iterators;l=$lifetime;t=$trait;awJF=$actixwebJF;awRS=$actixwebRS;pt=$codeSnippetPlaceholderTramsform;ro=$routers}

  $label=$labels.$key
  Write-Host "$label in Rust" -ForegroundColor Green
  $map.$key | format-table
}

function Disable-Taskbar-Flashing{
  Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name "ForegroundFlashCount" -Value 1
}

function New-LocalCert {
  param(
    [Parameter(Mandatory, HelpMessage='127.0.0.1 localhost ::1 IPAddr')]
    [string[]]$Names,

    [string]$CertFile = "cert.pem",
    [string]$KeyFile  = "key.pem",
    [string]$OutDir   = (Get-Location).Path
  )

  $certPath = Join-Path $OutDir $CertFile
  $keyPath  = Join-Path $OutDir $KeyFile

  $margs = @("-cert-file", $certPath, "-key-file", $keyPath) + $Names
  mkcert @margs

  Write-Host "✔ Certificate: $certPath" -ForegroundColor Green
  Write-Host "✔ Key:         $keyPath"  -ForegroundColor Green
}

function Install-LocalCA {
  $caRoot = (mkcert -CAROOT).Trim()
  Write-Host "CA root: $caRoot"
  mkcert -install
}

function Modify-Readline-History {
  code (Get-PSReadLineOption).HistorySavePath
}

function Get-Postgres-ConnectionString {
  param(
      [string]$EnvFile = ".env"
  )

  if (-not (Test-Path $EnvFile)) {
      throw "Env file not found: $EnvFile (resolved to '$((Resolve-Path -ErrorAction SilentlyContinue $EnvFile).Path)')"
  }

  $envVars = @{}
  Get-Content $EnvFile | ForEach-Object {
    $line = $_.Trim()
    if ($line -and -not $line.StartsWith('#')) {
      $name, $value = $line -split '=', 2
      $value = $value.Trim().Trim('"').Trim("'")
      $envVars[$name.Trim()] = $value
    }
  }

  $pgUser  = $envVars['POSTGRES_USER']
  $pgPass  = [uri]::EscapeDataString($envVars['POSTGRES_PASSWORD'])
  $pgHost  = if ($envVars['DB_HOST'] -eq 'db') { 'localhost' } else { $envVars['DB_HOST'] }
  $pgPort  = $envVars['DB_PORT']
  $pgDb    = $envVars['POSTGRES_DB']

  return "postgresql://${pgUser}:${pgPass}@${pgHost}:${pgPort}/${pgDb}"
}

function Invoke-Api-With-Curl {
  param(
    [Parameter(Mandatory)][string]$Url,
    [Parameter(Mandatory)][string]$Body,
    [ValidateSet(
      'text/plain',
      'application/json',
      'application/xml',
      'application/x-www-form-urlencoded',
      'multipart/form-data'
    )][string]$ContentType = 'application/x-www-form-urlencoded',
    [ValidateSet('GET','POST','PUT','PATCH','DELETE')][string]$Method = 'POST'
  )

  if ($Body.StartsWith("@")) {
    curl.exe -X $Method $Url -H "Content-Type: $ContentType" --data-binary "`"$Body`""
  } else {
    curl.exe -X $Method $Url -H "Content-Type: $ContentType" -d $Body
  }
}

function Inspect-Docker-Container-ENV {
  param([string]$Service='api')
  docker inspect $(docker compose ps -q $Service) --format '{{json .Config.Env}}'
}

function Open-PSReadline-History{
  code (Get-PSReadLineOption).HistorySavePath
}

function Monitor-DockerLog-Redis {
  docker compose exec redis redis-cli MONITOR
}

function Monitor-DockerLog-Postgres {
  # Inside psql (docker compose exec db psql -U admin -d test_db)
  # ALTER SYSTEM SET log_statement = 'all'; SELECT pg_reload_conf();
  # dupliate the console window
  # docker compose logs -f db
}

# Postgres Make [stable(since="0.1.0")]
# ---------------------------------------------------------------
function New-DotEnv-Postgres {
  param(
    [Parameter(Mandatory, HelpMessage='app name')]
    [string]$appName
  )

@"
POSTGRES_USER=admin
POSTGRES_PASSWORD=admin
POSTGRES_DB=${appName}
DB_HOST=db
DB_PORT=5432

PGADMIN_DEFAULT_EMAIL: admin@example.com
PGADMIN_DEFAULT_PASSWORD: admin
"@ | Set-Content '.env' -Encoding UTF8
}


# Rust Make [stable(since="0.1.0")]
# ---------------------------------------------------------------
function Get-Cargo-Workspace {
  param(
    [Parameter(Mandatory, HelpMessage='workspace name')]
    [String]$workspaceName
  )
  $dir = Join-Path $pwd $workspaceName
  If (-not (Test-Path $dir)) { mkdir $dir | Out-Null }

@"
[workspace]
resolver= "3"
members = ["crates/*"]
"@ | Set-Content -Path "$dir/Cargo.toml" -Encoding UTF8
}

function New-DotCargo-ConfigToml-SqlxOffline {
  param([string]$dst='.')
  if (-not (Test-Path "$dst/Cargo.toml")) { return }

  $dir = Join-Path $dst ".cargo"
  $file = Join-Path $dir "config.toml"
  if (-not (Test-Path $dir)) {
    New-Item -ItemType Directory -Path $dir | Out-Null
  }
  if (-not (Test-Path $file)) {
@"
[env]
SQLX_OFFLINE = "true"
"@ | Set-Content -Path $file -Encoding UTF8 -Force
  }
}

function Run-Cargo-Watch {
  param(
    [Parameter(Mandatory, HelpMessage='/src')]
    [String]$src
  )
  if (Test-Path($src)) {cargo watch -q -c -w $src -x run}
}

function Run-WatchExec-Cargo {
  param(
    [ValidateSet('rs','src')]
    [string]$x="rs"
  )
  watchexec -e $x -r cargo run
}

function New-RustInfra {
  param(
    [Parameter(Mandatory, HelpMessage='service name')]
    [string]$Name
  )
  if (-not (Test-Path "Cargo.toml")) {
    Write-Host "Cargo.toml NotFound" -ForegroundColor Red
    return
  }

  New-WebApi-Rust $Name
  New-SharedService
}

function New-RustCompose {
  param(
    [Parameter(Mandatory, HelpMessage='app name')]
    [string]$appName,
    [Parameter(Mandatory,HelpMessage='service:port from Compose.yml')]
    [string]$serverAddr
  )
  if (-not (Test-Path "./Cargo.toml")) { return }

  New-DotEnv-Actix $appName
  New-Config-Nginx $serverAddr
  Get-Dockfire-Family
}

function New-DotEnv-Actix {
  param(
    [Parameter(Mandatory, HelpMessage='app name')]
    [string]$appName
  )
  if (-not (Test-Path "./Cargo.toml")) { return }

@"
BIND_ADDR=127.0.0.1:8080

REDIS_URL=redis://127.0.0.1:6379

DATABASE_URL=postgresql://admin:admin@localhost:5432/${appName}

POSTGRES_USER=admin
POSTGRES_PASSWORD=admin
POSTGRES_DB=${appName}
DB_HOST=db
DB_PORT=5432
"@ | Set-Content '.env'
}

function New-SharedService {
  param([string]$dst='.')
  if (-not (Test-Path "$dst/Cargo.toml")) {
    Write-Host "Cargo.toml NotFound" -ForegroundColor Red
    return
  }
  $dir = Join-Path $dst "src/shared"
  New-Item -ItemType Directory -Path $dir -Force | Out-Null

@"
use redis::AsyncCommands;

#[derive(Clone)]
pub struct CacheService {
    pool: deadpool_redis::Pool,
    prefix: String,
    default_ttl: u64,
}
#[allow(unused)]
impl CacheService {
    pub fn new(url: &str, prefix: &str, default_ttl: u64) -> Self {
        let cfg = deadpool_redis::Config::from_url(url);
        let pool = cfg
            .create_pool(Some(deadpool_redis::Runtime::Tokio1))
            .expect("failed to create Redis pool");
        Self {
            pool,
            prefix: prefix.into(),
            default_ttl,
        }
    }

    fn key(&self, key: &str) -> String {
        format!("{}:{}", self.prefix, key)
    }

    pub async fn get(&self, key: &str) -> Option<String> {
        let mut conn = self.pool.get().await.ok()?;
        conn.get::<_, Option<String>>(self.key(key))
            .await
            .ok()
            .flatten()
    }

    pub async fn set(&self, key: &str, value: &str, ttl: Option<u64>) -> bool {
        let mut conn = match self.pool.get().await {
            Ok(c) => c,
            Err(_) => return false,
        };
        let ttl = match ttl {
            Some(t) => t,
            None => self.default_ttl + rand::random_range(0..=30),
        };
        conn.set_ex::<_, _, ()>(self.key(key), value, ttl)
            .await
            .is_ok()
    }

    pub async fn delete(&self, key: &str) -> bool {
        let mut conn = match self.pool.get().await {
            Ok(c) => c,
            Err(_) => return false,
        };
        conn.del::<_, usize>(self.key(key)).await.is_ok()
    }

    pub async fn get_or_load<F, Fut>(&self, key: &str, loader: F) -> Option<String>
    where
        F: FnOnce() -> Fut,
        Fut: std::future::Future<Output = Option<String>>,
    {
        if let Some(cached) = self.get(key).await {
            return Some(cached);
        }
        let value = loader().await?;
        let _ = self.set(key, &value, None).await;
        Some(value)
    }

    pub async fn ttl(&self, key: &str) -> Option<u64> {
        let mut conn = match self.pool.get().await {
            Ok(c) => c,
            Err(_) => return None,
        };
        let secs: i64 = conn.ttl(self.key(key)).await.ok()?;
        match secs {
            -2 => None,    // key doesn't exist
            -1 => Some(0), // key exists, no expiry set
            n if n > 0 => Some(n as u64),
            _ => None, // shouldn't happen, but be safe
        }
    }
}
"@ | Set-Content -Path "$dir/cache.rs" -Encoding UTF8

@"
use std::{
    collections::HashMap,
    sync::{Arc, Mutex},
    time::Instant,
};

#[derive(Clone)]
pub struct RateLimiter {
    hits: Arc<Mutex<HashMap<String, (u32, Instant)>>>,
}
impl RateLimiter {
    pub fn new() -> Self {
        Self {
            hits: Arc::new(Mutex::new(HashMap::new())),
        }
    }
    pub fn check(&self, key: &str, limit: u32, window_secs: u64) -> bool {
        let mut map = self.hits.lock().unwrap();
        let now = std::time::Instant::now();
        let entry = map.entry(key.to_string()).or_insert((0, now));
        if now.duration_since(entry.1) > std::time::Duration::from_secs(window_secs) {
            *entry = (0, now);
        }
        entry.0 += 1;
        entry.0 <= limit
    }
}
impl Default for RateLimiter {
    fn default() -> Self {
        Self::new()
    }
}
"@ | Set-Content -Path "$dir/rate_limit.rs" -Encoding UTF8

@"
use actix_web::{FromRequest, HttpRequest, error::ErrorUnauthorized, Error, dev::Payload,};
use jsonwebtoken::{encode, Header, EncodingKey};
use crate::user::{User, UserError};
use jsonwebtoken::{decode, DecodingKey, Validation, Algorithm};

#[derive(Debug, serde::Deserialize)]
pub struct AuthUser {
    pub id: uuid::Uuid,
    pub is_superuser: bool,
}

impl FromRequest for AuthUser {
    type Error = Error;
    type Future = std::future::Ready<Result<Self, Self::Error>>;

    fn from_request(req: &HttpRequest, _payload: &mut Payload) -> Self::Future {
        let result = req.headers()
            .get("Authorization")
            .and_then(|v| v.to_str().ok())
            .and_then(|v| v.strip_prefix("Bearer "))
            .and_then(|token| {
                let secret = std::env::var("JWT_SECRET").unwrap_or_default();
                decode::<Claims>(
                    token,
                    &DecodingKey::from_secret(secret.as_bytes()).unwrap(),
                    &Validation::new(Algorithm::HS256),
                )
                .ok()
            })
            .map(|data| AuthUser {
                id: data.claims.sub,
                is_superuser: data.claims.is_superuser,
            });

        std::future::ready(result.ok_or(ErrorUnauthorized("unauthorized")))
    }
}

#[derive(serde::Serialize, serde::Deserialize)]
pub struct Claims {
    pub sub: uuid::Uuid,
    pub is_superuser: bool,
    pub exp: usize,
}

pub fn generate_jwt(user: &User) -> Result<String, UserError> {
    let secret = std::env::var("JWT_SECRET")
        .expect("JWT_SECRET env var not set");

    let claims = Claims {
        sub: user.id,
        is_superuser: user.is_superuser,
        exp: (chrono::Utc::now() + chrono::Duration::hours(24)).timestamp() as usize,
    };

    encode(
        &Header::default(),  // HS256
        &claims,
        &EncodingKey::from_secret(secret.as_bytes()).unwrap(),
    )
    .map_err(|e| UserError::Db(sqlx::Error::Configuration(
        format!("jwt encode: {e}").into()
    )))
}
"@ | Set-Content -Path "$dir/auth.rs" -Encoding UTF8

@"
pub mod cache;
pub mod rate_limit;
// pub mod auth;

pub use cache::CacheService;
pub use rate_limit::RateLimiter;
"@ | Set-Content -Path "$dir/mod.rs" -Encoding UTF8

  Write-Host "Created src\shared\ - add 'mod shared;' to main.rs" -ForegroundColor Green
}

function New-WebApi-Rust {
  param(
    [Parameter(Mandatory, HelpMessage='service name')]
    [string]$Name
  )
  if (-not (Test-Path "Cargo.toml")) {
    Write-Host "Cargo.toml NotFound" -ForegroundColor Red
    return
  }
  $Name = $($Name.ToLower())
  $parentDir = 'src/modules'
  if (-not (Test-Path $parentDir)) { 
    New-Item -ItemType Directory -Path $parentDir -Force | Out-Null
  }

  $dstDir = Join-Path $parentDir $Name
  New-Item -ItemType Directory -Path $dstDir -Force | Out-Null

  $Name = $Name.Substring(0,1).ToUpper() + $Name.Substring(1)

@"
pub mod $($Name.ToLower());
"@ | Add-Content -Path "$parentDir/mod.rs" -Encoding UTF8 -Force

@"
pub mod error;
pub mod handler;
pub mod model;
pub mod service;

pub use error::${Name}Error;
pub use model::${Name};
pub use service::${Name}Service;

pub type ServiceResult<T> = Result<T, ${Name}Error>;

pub fn routes(cfg: &mut actix_web::web::ServiceConfig) {
    cfg.service(
        actix_web::web::scope("/$($Name.ToLower())s")
            // .route("/", actix_web::web::get().to(handler::list))
            // .route("/{id}", actix_web::web::get().to(handler::get))
            // .route("/", actix_web::web::post().to(handler::create))
            // .route("/{id}", actix_web::web::patch().to(handler::update))
            // .route("/{id}", actix_web::web::delete().to(handler::delete)),
    );
}
"@ | Set-Content -Path "$dstDir/mod.rs" -Encoding UTF8

@"
use crate::{$($Name.ToLower())::{${Name}, ${Name}Error, ServiceResult}, shared::CacheService};

#[derive(Clone)]
pub struct ${Name}Service {
    pool: sqlx::PgPool,
    cache: CacheService,
}

impl ${Name}Service {
    const LIST_KEY: &'static str = "$($Name.ToLower())s:all";
    const TTL: u64 = 60;

    fn cache_key(id: &uuid::Uuid) -> String {
        format!("$($Name.ToLower()):{}", id)
    }

    pub fn new(pool: sqlx::PgPool, cache: CacheService) -> Self { Self { pool, cache } }
    // --- READ ---
    pub async fn list(&self) -> ServiceResult<Vec<${Name}>> {
        // cache hit?
        if let Some(json) = self.cache.get(Self::LIST_KEY).await {
            if let Ok(rows) = serde_json::from_str::<Vec<${Name}>>(&json) {
                return Ok(rows);
            }
        }
        // cache miss -> DB
        let rows = sqlx::query_as!(
            ${Name},
            "SELECT * FROM $($Name.ToLower())s ORDER BY created_at DESC LIMIT 100"
        )
        .fetch_all(&self.pool)
        .await?;
        // cache it
        if let Ok(json) = serde_json::to_string(&rows) {
            self.cache.set(Self::LIST_KEY, &json, Some(Self::TTL)).await;
        }
        Ok(rows)
    }

    pub async fn get_by_id(&self, id: uuid::Uuid) -> ServiceResult<${Name}> {
        let key = Self::cache_key(&id);
        // cache hit?
        if let Some(json) = self.cache.get(&key).await {
            if let Ok(row) = serde_json::from_str::<${Name}>(&json) {
                return Ok(row);
            }
        }
        // cache miss -> DB
        let row = sqlx::query_as!(${Name},"SELECT * FROM $($Name.ToLower())s WHERE id = `$1", id)
        .fetch_optional(&self.pool)
        .await?
        .ok_or(${Name}Error::NotFound(id))?;
        // cache it
        if let Ok(json) = serde_json::to_string(&row) {
            self.cache.set(&key, &json, Some(Self::TTL)).await;
        }
        Ok(row)
    }

    // --- WRITE ---
    pub async fn create(&self, title: &str, content: &str) -> ServiceResult<${Name}> {
        let row = sqlx::query_as!(
            ${Name},
            "INSERT INTO $($Name.ToLower())s (title, content, published)
             VALUES (`$1, `$2, false) RETURNING *",
            title, content
        )
        .fetch_one(&self.pool)
        .await?;
        self.cache.delete(Self::LIST_KEY).await;
        Ok(row)
    }

    pub async fn update(
        &self,
        id: uuid::Uuid,
        title: Option<&str>,
        content: Option<&str>,
        published: Option<bool>,
    ) -> ServiceResult<${Name}> {
        let row = sqlx::query_as!(
            ${Name},
            r#"UPDATE $($Name.ToLower())s
               SET title      = COALESCE(`$2, title),
                   content    = COALESCE(`$3, content),
                   published  = COALESCE(`$4, published),
                   updated_at = now()
               WHERE id = `$1
               RETURNING *"#,
            id, title, content, published
        )
        .fetch_optional(&self.pool)
        .await?
        .ok_or(${Name}Error::NotFound(id))?;

        let key = Self::cache_key(&id);
        self.cache.delete(&key).await;
        self.cache.delete(Self::LIST_KEY).await;
        Ok(row)
    }

    pub async fn delete(&self, id: uuid::Uuid) -> ServiceResult<()> {
        let result = sqlx::query!("DELETE FROM $($Name.ToLower())s WHERE id = `$1", id)
            .execute(&self.pool)
            .await?;
        if result.rows_affected() == 0 {
            return Err(${Name}Error::NotFound(id));
        }
        let key = Self::cache_key(&id);
        self.cache.delete(&key).await;
        self.cache.delete(Self::LIST_KEY).await;
        Ok(())
    }
}
"@ | Set-Content -Path "$dstDir/service.rs" -Encoding UTF8

@"
use crate::{$($name.ToLower())::${Name}Error, state::AppState};
use actix_web::{web, HttpResponse, Responder};

// --- DTOs ---

#[derive(Debug, serde::Deserialize)]
pub struct Create${Name}Schema {
  // pub title: String,
  // pub content: String,
}

#[derive(Debug, serde::Deserialize)]
pub struct Update${Name}Schema {
  // pub title: Option<String>,
  // pub content: Option<String>,
  // pub published: Option<bool>,
}

// --- Handlers ---

pub async fn create(
    body: web::Json<Create${Name}Schema>,
    state: web::Data<AppState>,
) -> Result<impl Responder, ${Name}Error> {
    let row = state.$($name.ToLower())s.create(&body.title, &body.content).await?;
    Ok(HttpResponse::Created().json(row))
}

pub async fn list(state: web::Data<AppState>) -> Result<impl Responder, ${Name}Error> {
    let rows = state.$($name.ToLower())s.list().await?;
    Ok(HttpResponse::Ok().json(rows))
}

pub async fn get(
    id: web::Path<uuid::Uuid>,
    state: web::Data<AppState>,
    req: actix_web::HttpRequest,
) -> Result<impl Responder, ${Name}Error> {
    let client_ip = req
        .connection_info()
        .realip_remote_addr()
        .unwrap_or("unknown")
        .to_string();
    if !state.ratelimiter.check(&client_ip, 10, 60) {
        return Err(${Name}Error::RateLimited);
    }
    let row = state.$($name.ToLower())s.get_by_id(id.into_inner()).await?;
    Ok(HttpResponse::Ok().json(row))
}

pub async fn update(
    id: web::Path<uuid::Uuid>,
    body: web::Json<Update${Name}Schema>,
    state: web::Data<AppState>,
) -> Result<impl Responder, ${Name}Error> {
    let row = state.$($name.ToLower())s
        .update(
            id.into_inner(),
            body.title.as_deref(),
            body.content.as_deref(),
            body.published,
        )
        .await?;
    Ok(HttpResponse::Ok().json(row))
}

pub async fn delete(
    id: web::Path<uuid::Uuid>,
    state: web::Data<AppState>,
) -> Result<impl Responder, ${Name}Error> {
    state.$($name.ToLower())s.delete(id.into_inner()).await?;
    Ok(HttpResponse::NoContent().finish())
}

"@ | Set-Content -Path "$dstDir/handler.rs" -Encoding UTF8

@"
#[derive(Debug, serde::Serialize, serde::Deserialize, sqlx::FromRow)]
pub struct ${Name} {
// pub id: uuid::Uuid,
// pub title: String,
// pub content: String,
// pub published: bool,
// pub created_at: chrono::DateTime<chrono::Utc>,
// pub updated_at: chrono::DateTime<chrono::Utc>,
}
"@ | Set-Content -Path "$dstDir/model.rs" -Encoding UTF8

@"
use actix_web::http::StatusCode;

#[derive(Debug, thiserror::Error)]
pub enum ${Name}Error {
    #[error("not found: {0}")]
    NotFound(uuid::Uuid),
    #[error("db: {0}")]
    Db(#[from] sqlx::Error),
    #[error("rate limit exceeded")]
    RateLimited,
    // #[error("validation: {0}")]
    // Validation(String),
    // #[error("conflict: {0}")]
    // Conflict(String),
}
impl actix_web::ResponseError for ${Name}Error {
    fn status_code(&self) -> StatusCode {
        match self {
            ${Name}Error::NotFound(_) => StatusCode::NOT_FOUND,
            ${Name}Error::Db(_) => StatusCode::INTERNAL_SERVER_ERROR,
            ${Name}Error::RateLimited => StatusCode::TOO_MANY_REQUESTS,
            // ${Name}Error::Validation(_) => StatusCode::BAD_REQUEST,
            // ${Name}Error::Conflict(_) => StatusCode::CONFLICT,
        }
    }
    fn error_response(&self) -> actix_web::HttpResponse {
        actix_web::HttpResponse::build(self.status_code())
            .json(serde_json::json!({ "error": self.to_string() }))
    }
}
"@ | Set-Content -Path "$dstDir/error.rs" -Encoding UTF8

  Write-Host "Created $dstDir\ - add 'use modules::$($Name.ToLower());' to main.rs" -ForegroundColor Green
}

function MakeMigrations-Rust {
  if (-not (Test-Path './Cargo.toml')) { return }
  $dirModules = './src/modules'
  if (-not (Test-Path $dirModules)) { return }

  $services = Get-ChildItem -Path $dirModules -Attributes Directory -Exclude $excluded -Name
  $services.foreach({ MakeMigrations-Service $_ })
}

function MakeMigrations-Service {
  param(
    [Parameter(Mandatory, HelpMessage='service name')]
    [string]$serviceName,
    [int]$RowCount = 50
  )
  if (-not (Test-Path 'Cargo.toml')) {
    Write-Host 'Cargo.toml NotFound' -ForegroundColor Red
    return
  }
  $serviceName = $serviceName.ToLower()
  $path = "./src/modules/$serviceName/model.rs"
  if (-not (Test-Path $path)) {
    Write-Host "$path NotFound" -ForegroundColor Red
    return
  }

  $content = Get-Content $path -Raw
  $lines = $content -split "`n"

  # --- find the struct with FromRow, extract fields line by line ---
  $fields = @()
  $startIdx = -1
  for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match 'FromRow') { $startIdx = $i; break }
  }
  if ($startIdx -eq -1) {
    Write-Host "No struct with FromRow found in $path" -ForegroundColor Red
    return
  }

  # find the opening brace
  for ($i = $startIdx; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '\{') { $startIdx = $i; break }
  }

  # read fields until closing brace
  for ($i = $startIdx + 1; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '^\s*\}') { break }
    if ($lines[$i] -match '^\s*pub\s+(\w+)\s*:\s*(.+?)\s*[,;]?\s*$') {
      $fields += [PSCustomObject]@{ Col = $Matches[1]; Type = $Matches[2].Trim() }
    }
  }

  if ($fields.Count -eq 0) {
    Write-Host "No fields found" -ForegroundColor Red
    return
  }

  # derive struct name from the pub struct line (between FromRow and the brace)
  for ($i = $startIdx; $i -ge 0; $i--) {
    if ($lines[$i] -match 'pub struct (\w+)') {
      $structName = $Matches[1]
      break
    }
  }
  $tableName = $structName.ToLower()

  # --- build DDL + fake data ---
  $fieldObjs = @()
  foreach ($f in $fields) {
    $col = $f.Col
    $rustType = $f.Type

    $ddl = switch ($rustType) {
      'uuid::Uuid'                    { "    $col UUID PRIMARY KEY DEFAULT gen_random_uuid()" }
      'String'                        { "    $col TEXT NOT NULL" }
      'bool'                          { "    $col BOOLEAN NOT NULL DEFAULT false" }
      'i32'                           { "    $col INTEGER NOT NULL" }
      'i64'                           { "    $col BIGINT NOT NULL" }
      'f64'                           { "    $col DOUBLE PRECISION NOT NULL" }
      'chrono::DateTime<chrono::Utc>' { "    $col TIMESTAMPTZ NOT NULL DEFAULT now()" }
      'rust_decimal::Decimal'         { "    $col NUMERIC NOT NULL" }
      default { Write-Warning "Unknown type: $rustType (column: $col)"; $null }
    }

    if ($ddl) {
      # --- special cases by column name (takes priority over type) ---
      $fake = switch ($col) {
        'email'         { "'${structName}' || lpad(i::text, 2, '0') || '@example.com'" }
        'username'      { "'${structName}' || lpad(i::text, 2, '0')" }
        'password_hash' { "'`$argon2id`$v=19`$m=19456,t=2,p=1`$fakeSalt`$fakeHash'" }
        'phone'         { "'555-01' || lpad(i::text, 2, '0')" }
        default         {
          switch ($rustType) {
            'uuid::Uuid'                    { $null }
            'String'                        { "'${structName} ' || i" }
            'bool'                          { "(i % 3 = 0)" }
            'i32'                           { "i" }
            'i64'                           { "i" }
            'f64'                           { "(i * 1.5)" }
            'chrono::DateTime<chrono::Utc>' { "now() - (i || ' hours')::interval" }
            'rust_decimal::Decimal'         { "(i * 10.5)" }
          }
        }
      }
      $fieldObjs += [PSCustomObject]@{ Col = $col; Ddl = $ddl; Fake = $fake }
    }
  }

  # --- CREATE TABLE ---
  $create = "CREATE TABLE IF NOT EXISTS ${tableName}s (`n$($fieldObjs.Ddl -join ",`n")`n);"

  # --- INSERT ---
  $insertCols = $fieldObjs | Where-Object { $_.Fake }
  $colList = ($insertCols.Col -join ",")
  $valList = "  " + ($insertCols.Fake -join ",`n  ")

  $insert = @"
INSERT INTO ${tableName}s ($colList)
SELECT
$valList
FROM generate_series(1, ${RowCount}) AS i;
"@

  # --- Out ---
  $dstDir = "./migrations"
  if (-not (Test-Path $dstDir)) {
    New-Item -ItemType Directory -Path $dstDir -Force | Out-Null
  }
  $dstFilename = Join-Path $dstDir "${tableName}_init.sql"
  "$create`n`n$insert" | Set-Content -Path $dstFilename -Encoding UTF8
  Write-Host "Wrote $dstFilename" -ForegroundColor Green
}

function Migrate-Rust {
  param(
    [string]$SourceDir = "./migrations",
    [string]$OutputFile = "./init.sql"
  )

  if (-not (Test-Path $SourceDir)) { return }

  $files = Get-ChildItem -Path $SourceDir -Filter "*.sql" | Sort-Object Name

  if ($files.Count -eq 0) {
    Write-Warning "No .sql files found in $SourceDir"
    return
  }

  $content = $files | ForEach-Object {
    # Write-Host "Merging: $($_.Name)"
    # "# ---- $($_.Name) ----"
    Get-Content -Path $_.FullName -Raw
    ""  # blank line separator
  }

  $content | Set-Content -Path $OutputFile -Encoding UTF8
  # Write-Host "Wrote $($files.Count) files -> $OutputFile"
}

function Generate-HttpTests-Rust {
  if (-not (Test-Path './Cargo.toml')) { return }
  $excluded = @('shared','*app')
  $services = Get-ChildItem -Path './src/modules' -Directory -Exclude $excluded -Name
  $services.foreach({ Generate-JsonDataHttpTest-Rust $_ })
}

function Generate-JsonDataHttpTest-Rust {
  param(
    [Parameter(Mandatory, HelpMessage='service name')]
    [string]$serviceName,
    [int]$Count = 5
  )

  if (-not (Test-Path 'Cargo.toml')) {
    Write-Host 'Cargo.toml NotFound' -ForegroundColor Red
    return
  }
  $serviceName = $serviceName.ToLower()
  $path = "./src/modules/$serviceName/model.rs"
  if (-not (Test-Path $path)) {
    Write-Host "$path NotFound" -ForegroundColor Red
    return
  }

  $content = Get-Content $path -Raw
  $lines = $content -split "`n"

  # --- find the struct with FromRow, extract its fields line by line ---
  $fields = @()
  $inTarget = $false
  $braceDepth = 0

  foreach ($line in $lines) {
    if (-not $inTarget) {
      if ($line -match 'FromRow') {
        $inTarget = $true
        # if the struct opening brace is on the same line, count it
        if ($line -match '\{') { $braceDepth = 1 }
      }
      continue
    }

    # count braces to handle the closing }
    $opens  = ([regex]::Matches($line, '\{')).Count
    $closes = ([regex]::Matches($line, '\}')).Count
    $braceDepth += $opens - $closes

    if ($braceDepth -le 0) { break }

    if ($line -match '^\s*pub\s+(\w+)\s*:\s*(.+?)\s*[,;]?\s*$') {
      $fields += [PSCustomObject]@{ Col = $Matches[1]; Type = $Matches[2].Trim() }
    }
  }

  if ($fields.Count -eq 0) {
    Write-Host "No fields found in $path" -ForegroundColor Red
    return
  }

  $words = @('The','Quick','Brown','Fox','Jumps','Over','Lazy','Dogs','Rust','Actix','Postgres','Async','Service','Handler','Route','Cache','Redis','Docker','Caddy','Nginx','Lorem','Ipsum','Dolor','Sit','Amet')

  $rows = 1..$Count | ForEach-Object {
    $i = $_
    $created = (Get-Date).AddHours(-$i).ToUniversalTime()
    $updated = $created.AddMinutes((Get-Random -Max 60))
    $obj = [ordered]@{}

    foreach ($f in $fields) {
      $col = $f.Col
      $rustType = $f.Type

      foreach ($f in $fields) {
        $col = $f.Col
        $rustType = $f.Type

        # --- special cases (by column name) ---
        if ($col -eq 'email') {
          $obj[$col] = "user$i@example.com"
        }
        elseif ($col -eq 'username') {
          $obj[$col] = "user$i"
        }
        elseif ($col -eq 'password_hash') {
          $obj[$col] = '$argon2id$v=19$m=19456,t=2,p=1$fakeSalt$fakeHash'
        }
        elseif ($col -eq 'phone') {
          $obj[$col] = "555-01$($i.ToString().PadLeft(2,'0'))"
        }
        else {
          # --- generic type handling ---
          switch ($rustType) {
            'uuid::Uuid'                          { $obj[$col] = [guid]::NewGuid().ToString() }
            'String' {
              $n = 3 + (Get-Random -Max 4)
              $w = 1..$n | ForEach-Object { $words[(Get-Random -Max $words.Count)] }
              $obj[$col] = ($w -join ' ')
            }
            'bool'                                { $obj[$col] = (Get-Random -Max 3) -eq 0 }
            'i32'                                 { $obj[$col] = $i }
            'i64'                                 { $obj[$col] = $i }
            'f64'                                 { $obj[$col] = [math]::Round($i * 1.5, 2) }
            'chrono::DateTime<chrono::Utc>' {
              if ($col -eq 'created_at') {
                $obj[$col] = $created.ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
              } else {
                $obj[$col] = $updated.ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
              }
            }
            'rust_decimal::Decimal'               { $obj[$col] = [math]::Round($i * 10.5, 2) }
            default { Write-Warning "Unknown type: $rustType (column: $col) — skipping" }
          }
        }
      }
    }
    [PSCustomObject]$obj
  }

  $dstDir = "./test"
  if (-not (Test-Path $dstDir)) {
    New-Item -ItemType Directory -Path $dstDir -Force | Out-Null
  }
  $dstFilename = Join-Path $dstDir "${serviceName}_fakedata.json"
  $rows | ConvertTo-Json -Depth 5 | Set-Content -Path $dstFilename -Encoding UTF8
  New-HttpTest $dstDir $serviceName
}

function New-HttpTest {
  param(
    [Parameter(Mandatory, HelpMessage='folder name')]
    [string]$dir,
    [Parameter(Mandatory, HelpMessage='service name')]
    [string]$serviceName
  )
  $dstFilename = Join-Path $dir "${serviceName}_test_api.http"
@"
@baseUrl = http://0.0.0.0:80
@scope = ${serviceName}s
@id = f288799e-6a07-4a3a-b20a-50b05df45683

### GET
GET {{baseUrl}}/

### LIST
GET {{baseUrl}}/{{scope}}/

### CREATE
POST {{baseUrl}}/{{scope}}/
Content-Type: application/json

{
  "id":  "ec734b68-c302-4a4a-9644-35ccab287746",
  "title":  "Route Jumps Nginx Service Caddy Over",
  "content":  "Caddy Docker Actix Actix Lazy Ipsum",
  "published":  false,
  "created_at":  "2026-11-20T09:35:47.847Z",
  "updated_at":  "2026-11-20T10:20:47.847Z"
}

### GET
GET {{baseUrl}}/{{scope}}/{{id}}

### UPDATE
PATCH {{baseUrl}}/{{scope}}/{{id}}
Content-Type: application/json

{
  "title":  "updated"
}

### DELTE
DELETE {{baseUrl}}/{{scope}}/{{id}}
"@ | Set-Content -Path $dstFilename -Encoding UTF8
}