{%- if cookiecutter.frontend_pipeline == 'Webpack' -%}
import '../sass/project.scss';

{% endif -%}
/* Project specific Javascript goes here. */
