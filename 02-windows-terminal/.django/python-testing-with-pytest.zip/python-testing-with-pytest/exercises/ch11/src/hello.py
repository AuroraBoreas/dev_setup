"""
hello(): return return "Hello, World!"
hello("Brian"): return "Hello, Brian!"
"""
__version__ = "0.0.1"


def world():
    return "Hello, World!"


def name(the_name):
    return f"Hello, {the_name}!"
