def full_output():
    return f"Hello, World!"


def main():
    print(full_output())


if __name__ == "__main__":
    main()
