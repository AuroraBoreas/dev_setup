import time


def test_something():
    time.sleep(1)
