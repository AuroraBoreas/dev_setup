import pytest


def test_normal():
    pass


@pytest.mark.slow
def test_slow():
    pass
