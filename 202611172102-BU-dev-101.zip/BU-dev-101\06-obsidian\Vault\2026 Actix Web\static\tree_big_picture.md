#HttpRequest arrives
##➡ Router (matches path)   ⬅ actix internal dispatch machine/mechanism
###➡ Resource (matched route)
####→ Guards (method, headers, etc.)
#####→ Extractors (Path, Json, Query, Form...)
######→ Your handler
#######→ HttpResponse