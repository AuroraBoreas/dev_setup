#App (top-level, holds everything)
##Scope("/api")               ← prefix
###Scope("/users")
####Resource("/")         ← one path, multiple methods
#####Route(GET)
#####Route(POST)
####Resource("/{id}")     ← one path, multiple methods
#####Route(GET)
#####Route(DELETE)
###Scope("/orders")
####...
###Resource("/health")
##Resouce("/favicon.ico")    ← outside any scope