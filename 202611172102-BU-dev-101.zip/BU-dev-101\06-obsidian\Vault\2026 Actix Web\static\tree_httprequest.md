
#HttpRequest
##inner                ⬅ hidden in most of web frameworks, it is irrelavent to users
###head: RequestHead ⬅ make it like `req.inner.head.method` -> `req.head.method`
####method
####uri
####version
####headers: HeaderMap
#####mask
#####indices
#####entries
#####extra_values
#####danger
####peer_addr
###extensions, etc.