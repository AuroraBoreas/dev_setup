# $host.ui.RawUI.WindowTitle = "🐱‍🚀🚀🌔"
# module
# Install-Module PSReadLine -Repository PSGallery -Scope CurrentUser -Force

# install NERD font
# oh-my-posh font install --user 0xProto
# oh-my-posh scheme: material, jblab_2021, larserikfinholt, json
# ---------------------------------------------------------------
& ([ScriptBlock]::Create((oh-my-posh init pwsh --config "$env:POSH_THEMES_PATH\clean-detailed.omp.json" --print) -join "`n"))

# permanent user-alias, 20231216 @ZL
# Python Make. [deprecated(in 2025. using uv instead)]
# ---------------------------------------------------------------
Function Create-Python-Venv {
  param(
    [Parameter(Mandatory)]
    [String]$projectName
  )
  if (!(Test-Path $projectName)) {
    New-Item $projectName -ItemType Directory | Out-Null
    Set-Location $projectName
    python -m venv .venv
    Write-Host "project at: $projectName" -ForegroundColor Green
  } else {
    Write-Host "failed to create project: $projectName" -ForegroundColor -Red
  }
}
Function Activate-Python-Venv {
  if ([System.Environment]::OSVersion.VersionString -like '*Unix*') {source .venv/bin/activate} else {.venv\scripts\activate}
}
Function Freeze-Python-Dependencies {pip freeze > requirements.txt}
# Function Get-Dependencies {param([string]$src="~/.django/requirements.txt",[string]$dst=".") Copy-Item -Path $src -Destination $dst -Force}
# Function Install-Dependencies {param([string]$Name="requirements.txt") pip install -r $Name}
# Function Uninstall-Dependencies {param([string]$Name="requirements.txt") pip uninstall -r $Name -y}
# Function Profile-Python-App {param([Parameter(Mandatory=$true)][string]$App) python -m cProfile -s cumtime $App}
# Function Update-Pip {python -m pip install --upgrade pip}
# Function Get-Pytest {
#   param([string]$src="~/.django/python-testing-with-pytest.zip",[string]$dst=".")
#   Expand-Archive -Path $src -DestinationPath $dst -Force
# }
# Function Generate-Pyproject-Structure {
#   param([Parameter(Mandatory=$true)][string]$ProjectName,[Parameter(Mandatory=$true)][string]$PackageName)
#   $dst = "$ProjectName/src/$PackageName"
#   mkdir $dst -Force
#   New-Item $dst/__init__.py -Force
#   New-Item $dst/__main__.py -Force
# }

Set-Alias getvenv Create-Python-Venv
Set-Alias source Activate-Python-Venv
Set-Alias freeze Freeze-Python-Dependencies
# Set-Alias getRqm Get-Dependencies
# Set-Alias rqm Install-Dependencies
# Set-Alias profile Profile-Python-App
# Set-Alias pipu Update-Pip
# Set-Alias pipc Uninstall-Dependencies
# Set-Alias getpytest Get-Pytest
# Set-Alias getpyproject Generate-Pyproject-Structure

# project templates !TODO, 20240616. [deprecated(in 2025. using uv instead)]
# ---------------------------------------------------------------
# Function Get-Cookiecutter-Django {
#   param([string]$src="~/.django/cookiecutter-django.zip")
#   cookiecutter $src
# }
# Function Get-Bootstrap-Template {
#   param([string]$src="~/.django/bootstrap-template-5.0.zip",[string]$dst=".")
#   Expand-Archive -Path $src -DestinationPath $dst -Force
# }

# Function Get-Frontend-Playground {
#   param([string]$src="~/.django/frontend-playground-1.0.zip",[string]$dst=".")
#   Expand-Archive -Path $src -DestinationPath $dst -Force
# }
# Function Get-Django-Dockerized {
#   param([string]$src="~/.django/django-dockerized-1.0.zip",[string]$dst=".")
#   Expand-Archive -Path $src -DestinationPath $dst -Force
# }

# Set-Alias getCCDJ Get-Cookiecutter-Django
# Set-Alias getBST Get-Bootstrap-Template
# Set-Alias getFrontend Get-Frontend-Playground
# Set-Alias getDjDk Get-Django-Dockerized

# Django Make, 20240427 [deprecated(in 2025. using ASP.NET instead)]
# ---------------------------------------------------------------
# Function Django-Admin-Createproject {param([Parameter(Mandatory=$true)][string]$Name) django-admin startproject $Name}
# Function Django-Admin-Startapp {param([Parameter(Mandatory=$true)][string]$Name) django-admin startapp $Name}
# Function Python-Manage-Runserver {python manage.py runserver}
# Function Python-Manage-Runserver-Dev {param([string]$IP="0.0.0.0:8000") python manage.py runserver $IP}
# Function Python-Manage-Makemigrations {
#   param([string]$Name=$null)
#   if ([string]::IsNullOrEmpty($Script)) {python manage.py makemigrations} else {python manage.py makemigrations $Name}
# }
# Function Python-Manage-Migrate {
#   param([string]$Name=$null)
#   if ([string]::IsNullOrEmpty($Script)) {python manage.py migrate} else {python manage.py migrate $Name}
# }
# Function Python-Manage-Createsuperuser {python manage.py createsuperuser}
# Function Python-Manage-Test {
#   param([string]$App=$null)
#   if ($App -eq $null) {python manage.py test} else {python manage.py test $App}
# }
# Function Python-Manage-Runscript {param([Parameter(Mandatory=$true)][string]$Name) python manage.py runscript $Name}
# Function Python-Upgrate-Pip-Install-Django {pip install django}
# Function Python-Manage-Command {
#   param([string]$Script,[int]$n=10)
#   if (!([string]::IsNullOrEmpty($Script))) {python manage.py $Script $n} else { Write-Host "FileNotFoundError: $Script" }
# }
# Function Python-Manage-Inspect {param([string]$Name="models.py") python manage.py inspectdb > $Name}
# Function Python-Manage-Shell {python manage.py shell_plus}
# Function Python-Manage-Check {python manage.py check --deploy}
# Function Profile-Django-Tests {
#   param([Parameter(Mandatory=$true)][string]$App,[bool]$Out=$false)
#   if ($Out) {python -m cProfile -s cumtime manage.py test $App 2>&1 > prof.txt}
#   else {
#     if ([System.Environment]::OSVersion.VersionString -like "*Unix*") {python -m cProfile -s cumtime manage.py test $App 2>&1 | less}
#     else {python -m cProfile -s cumtime manage.py test $App 2>&1 | more}
#   }
# }

# Set-Alias djsp Django-Admin-Createproject
# Set-Alias djsa Django-Admin-Startapp
# Set-Alias djrs Python-Manage-Runserver
# Set-Alias djrsdev Python-Manage-Runserver-Dev
# Set-Alias djmm Python-Manage-Makemigrations
# Set-Alias djmg Python-Manage-Migrate
# Set-Alias djcs Python-Manage-Createsuperuser
# Set-Alias djtest Python-Manage-Test
# Set-Alias djcmd Python-Manage-Command
# Set-Alias djrun Python-Manage-Runscript
# Set-Alias getdj Python-Upgrate-Pip-Install-Django
# Set-Alias djinspect Python-Manage-Inspect
# Set-Alias djshell Python-Manage-Shell
# Set-Alias djcheck Python-Manage-Check
# Set-Alias djprof Profile-Django-Tests


# C/C++ Make, 20240710
# ---------------------------------------------------------------
Function Get-Preprocess {param([string]$src='main.c') gcc -E $src}
Function Get-Assembly {param([string]$src='main.c') gcc -S $src}
Function Get-MachineCode {param([string]$src='main.c') gcc -c $src}
Function Get-Executable {param([string]$src='main.c', [string]$dst='a') gcc $src -o $dst}
Function Get-DumpTreeGraph {param([string]$src='main.c') gcc -fdump-tree-all-graph -g $src}
Function Get-ObjDump {param([string]$src='main.o') objdump $src}
Function Get-ld {param([string]$src) ld $src}


Set-Alias pre Get-Preprocess
Set-Alias asm Get-Assembly
Set-Alias cmc Get-MachineCode
Set-Alias bin Get-Executable
Set-Alias viz Get-DumpTreeGraph
Set-Alias obj Get-ObjDump


# Tutorial Video Make, 20240821. [deprecated(in 2025. worthless)]
# ---------------------------------------------------------------
# Function Get-Tutorial-Video-Template {
#   param([string]$src="~/.django/tutorial-creator.zip",[string]$dst=".")
#   Expand-Archive -Path $src -DestinationPath $dst -Force
# }

# Function Create-Tutorial-Video-Workspace {
#   param([Parameter(Mandatory=$true)][string]$DirName,[string]$what="Python-Tutorial-")
#   Get-Tutorial-Video-Template
#   mkdir $DirName -Force
#   $NewName = "$DirName-$What.pptx"
#   rename-item "./template.pptx" $NewName
#   move-item -Force $NewName $DirName
#   cd $DirName
#   new-item "story.md" -Force
#   new-item "main.py" -Force
#   "谢谢大家的观看。我们下次再见！欢迎点赞收藏转发，谢谢！" | Out-File -FilePath "storyteller.txt"
#   cd ..
# }

# Set-Alias getTV Create-Tutorial-Video-Workspace


# The following commands work only in Sonic PC(portable version), comment them out if error occurs, 20240124 @ZL
# VSCode
# ---------------------------------------------------------------
# Function Open-VSCode {param([string]$path=".") C:\D\DevEnv\VSCode-win32-x64-1\Code.exe -n $path}
# Set-Alias code Open-VSCode

# Mathematic Make [deprecated(in 2025. worthless)]
# ---------------------------------------------------------------
# Function Get-Math-Calculus {Code -n D:\Win-Mac-Share\2023_Assembly\20231115_Calculus_and_Analytic_Geometry}
# Set-Alias cg Get-Math-Calculus
# Function Get-Math-LinearAlgebra {Code -n D:\Win-Mac-Share\2023_Assembly\20240123_LA}
# Set-Alias la Get-Math-LinearAlgebra
# Function Get-Practical-ML {Code -n D:\Win-Mac-Share\2023_Assembly\20230707_Practical_Machine_Learning_with_Python}
# Set-Alias ml Get-Practical-ML
# Function Get-Math-Discrete {Code -n D:\Win-Mac-Share\2023_Assembly\20240316_DiscreteMath}
# Set-Alias dm Get-Math-Discrete
# Function Get-Math-AbstractAlgebra {Code -n D:\Win-Mac-Share\2023_Assembly\20240404_AbstractAlgebra}
# Set-Alias aa Get-Math-AbstractAlgebra
# Function Get-The-Art-Of-Electronics {Code -n D:\Win-Mac-Share\2023_Assembly\20240725_the_art_of_electronics}
# Set-Alias aoe Get-The-Art-Of-Electronics
# Function Get-Design-of-Experiments {Code -n D:\Win-Mac-Share\2023_Assembly\20140801_DOE}
# Set-Alias doe Get-Design-of-Experiments

# DevEnvBackup [deprecated(in 2025. macpro dead)]
# ---------------------------------------------------------------
Function Backup-Dev-Env-Settings {
  $root = '~'
  $buDir="$root\BU-dev-101\"
  If (!(Test-Path $buDir)) {mkdir $buDir | Out-Null}

  # --- vscode ---
  $dst="$buDir\01-vscode"
  If (!(Test-Path $dst)) {mkdir $dst | Out-Null}
  $editorName = 'Code'
  $srcPaths=(
    "$root\AppData\Roaming\$editorName\User\keybindings.json",
    "$root\AppData\Roaming\$editorName\User\settings.json",
    "$root\AppData\Roaming\$editorName\User\snippets\"
  )
  ForEach($SrcPath in $srcPaths) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}
  $extensions = code --list-extensions
  $extensions | Out-File -FilePath "$dst\vscode-extensions.txt" -Encoding utf8

  # --- windows terminal ---
  $dst="$buDir\02-windows-terminal\"
  If (!(Test-Path $dst)) {mkdir $dst | Out-Null}
  $srcPaths=(
    "$root\AppData\Local\Packages\Microsoft.WindowsTerminal_8wekyb3d8bbwe\LocalState\settings.json",
    "$root\Documents\WindowsPowerShell\Microsoft.PowerShell_profile.ps1"
  )
  ForEach($SrcPath in $srcPaths) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}

  # --- blender ---
  # $dst="$buDir\05-utilities\MyPkg\blender\preferences\user_config"
  # If (!(Test-Path $dst)) {mkdir $dst}
  # $SrcPath="$root\AppData\Roaming\Blender Foundation\Blender\4.1\config\userpref.blend"
  # If (Test-Path $SrcPath) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}

  # --- vs ---
  $dst="$buDir\03-vs"
  If (!(Test-Path $dst)) {mkdir $dst | Out-Null}
  $SrcPath="$root\Documents\Visual Studio 2022\Code Snippets"
  If (Test-Path $SrcPath) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}
  $SrcPath="C:\ProgramE\Program\Microsoft Visual Studio\Common7\IDE\VC\Snippets"
  If (Test-Path $SrcPath) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}

  # --- idea ---
  # manually bu

  # --- zed ---
  $dst="$buDir\05-zed"
  If (!(Test-Path $dst)) {mkdir $dst | Out-Null}
  $editorName = 'Zed'
  $srcPaths=(
    "$root\AppData\Roaming\$editorName\keymap.json",
    "$root\AppData\Roaming\$editorName\settings.json",
    "$root\AppData\Roaming\$editorName\snippets\"
  )
  ForEach($srcPath in $srcPaths) {Copy-Item -Path $srcPath -Destination $dst -Recurse -Force}

  # --- obsidian ---
  $dst="$buDir\06-obsidian"
  If (!(Test-Path $dst)) {mkdir $dst | Out-Null}
  $srcPath='~\ObsidianProjects\Vault'
  If (Test-Path $SrcPath) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}
  $excluded="$dst\Vault\.obsidian"
  If (Test-Path $excluded) {Remove-Item -force -recurse $excluded}

  # --- toolkit ---
  $dst=$buDir
  $folderPath='C:\ProgramE\Program\'
  If (Test-Path $folderPath) {
    $subfolders = Get-ChildItem -Path $folderPath -Directory
    $subfolders | Select-Object Name | Export-Csv -Path "$dst\devEnv.csv" -NoTypeInformation
  }

  $src=$buDir
  $timeStamp = Get-Date -Format 'yyyyMMddHHmm'
  $dst="$root\$timeStamp-BU-dev-101.zip"
  Compress-Archive -Path $src -DestinationPath $dst -Force
}

Function Update-VSCode-UserSnippet {
  param([string]$path="$root\BU-dev-101\01-vscode\snippets\")
  $dst="$root\AppData\Roaming\Code\User"
  if (Test-Path $dst) {
    Copy-Item -Path $path -Destination $dst -Force -Recurse
  }
}

#[deprecated. ditch django]
# Function Update-Django-Template {
#   param([string]$path="$root\BU-dev-101\02-windows-terminal\.django")
#   $dst="."
#   if (Test-Path $dst) {
#     Copy-Item -Path $path -Destination $dst -Force -Recurse
#   }
# }

Function Update-Dev-Env-Settings {
  $zipFileName="$root\Downloads\BU-dev-101.zip"
  $dstFolder="$root\BU-dev-101"
  if (Test-Path $dstFolder) {Remove-Item -Path $dstFolder -Force -Recurse}
  if (Test-Path $zipFileName) {
    Expand-Archive -Path $zipFileName -DestinationPath "~\" -Force
    Update-VSCode-UserSnippet
    Update-Django-Template
    Remove-Item -Path $zipFileName -Force -Recurse
  }
  else {Write-Host 'FileNotFoundError: `BU-dev-101.zip` in Downloads..'}
}

Set-Alias bu Backup-Dev-Env-Settings
Set-Alias up Update-Dev-Env-Settings

# Cargo workspace[stable(since="0.1.0")]
# ---------------------------------------------------------------
Function Get-Cargo-Workspace {
  param(
      [Parameter()]
      [String]$root='~/rustprojects',
      [String]$ProjectName='my-project'
  )
  $dst = "$root/$ProjectName/"
  If (!(Test-Path $dst)) {mkdir $dst | Out-Null}
  $configFile = 'Cargo.toml'
  $config = '[workspace]`r`nresolver=`"`3`"`r`n'
  New-Item -Path $dst/$configFile -Force -ItemType File -Value $config | Out-Null
  Write-Host "Workspace at: $dst" -ForegroundColor Green
}

#[deprecated. use cargo clippy -- -D clippy::pedantic -D clippy::nursery]
# Function Inject-Clippy-Config-Into-Cargo-Toml {
#   $configFile = "Cargo.toml"
#   $Config ="`r`n[lints.clippy]`r`npedantic = { level = `"`deny`", priority = -1 }`r`nnursery = { level = `"`deny`", priority = -1 }`r`nunwrap_used = `"`deny`"`r`nexpect_used = `"`deny`"`r`nindexing_slicing = `"`deny`"`r`narithmetic_side_effects = `"`deny`"`r`nunreachable = `"`deny`"`r`nunimplemented = `"`deny`"`r`nunchecked_time_subtraction = `"`deny`"`r`ntodo = `"`deny`"`r`nstring_slice = `"`deny`"`r`npanic_in_result_fn = `"`deny`"`r`npanic = `"`deny`"`r`nexit = `"`deny`"`r`nas_conversions = `"`deny`""
#   $Pwd = pwd
#   If (Test-Path $configFile) {
#     Add-Content -Path $configFile -Value $Config
#   } else {
#     Write-Warning "Failed. $configFile is not found in $Pwd"
#   }
# }

# Function Set-Clippy-Tomal {
#   $configFile = "clippy.toml"
#   $Config="allow-unwrap-in-tests = true`r`nallow-expect-in-tests = true`r`nallow-panic-in-tests = true`r`nallow-indexing-slicing-in-tests = true`r`n"
#   New-Item -Path $configFile -Force -ItemType File -Value $Config | Out-Null
# }

# Function Init-Cargo-Clippy {
#   try {
#     cargo clippy -- -D clippy::pedantic -D clippy::nursery
#   } catch {
#     Write-Host "Cargo not found." -ForegroundColor Red
#   }
# }

# User-defined Function for LSP or shortcuts[stable(since="0.1.0")]
# ---------------------------------------------------------------
Function Set-ProcMacro-Config {
  $pwd = pwd
  $configFile = 'Cargo.toml'
  $Config = 'syn = `"`2.0`"`r`nquote = `"`1.0`"`r`n`r`n[lib]`r`nproc-macro = true'

  If (Test-Path $configFile) {
    Add-Content -Path $configFile -Value $Config
  } else {
    Write-Warning "Failed. $configFile is not found in $pwd"
  }
}

Function Run-Cargo-Clippy {
  cargo clippy -- -D clippy::pedantic -D clippy::nursery
}

Function Run-Cargo-Watch {
  param(
    [Parameter(Mandatory)]
    [String]$src
  )
  if (Test-Path($src)) {cargo watch -q -c -w $src -x run}
}

Function Update-Powershell-PackageManager {
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

  $names = @('PowerShellGet', 'PackageManagement', 'Microsoft.PowerShell.PSResourceGet')
  Get-Module -Name $names -ListAvailable
  Find-Module -Name $names -Repository PSGallery

  Install-Module PowerShellGet -Repository PSGallery -Force -AllowClobber
  Install-Module Microsoft.PowerShell.PSResourceGet -Repository PSGallery
}

Function Watch-Lua-Script {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)]
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [string]$path
  )
  $path = (Resolve-Path $path).Path
  $directory = Split-Path -Path $path -Parent
  $filename = Split-Path -Path $path -Leaf

  $watcher = New-Object System.IO.FileSystemWatcher
  $watcher.Path = $directory
  $watcher.Filter = $filename
  $watcher.NotifyFilter = [System.IO.NotifyFilters]::LastWrite -bor [System.IO.NotifyFilters]::FileName -bor [System.IO.NotifyFilters]::CreationTime
  $watcher.IncludeSubdirectories = $false

  $state = [hashtable]::Synchronized(@{ LastRun = [datetime]::MinValue })
  $msgData = @{ Path = $path; Debounce = 2; State = $state }

  $action = {
    $m = $Event.MessageData
    $now = Get-Date
    if (($now - $m.State.LastRun).TotalSeconds -lt $m.Debounce) { return }
    $m.State.LastRun = $now

    $evt = $Event.SourceEventArgs
    $msg = "$(Get-Date -Format 'HH:mm:ss') $($evt.ChangeType) $($evt.FullPath)"
    #$msg | Out-File ~\watch.log -Append
    Write-Host $msg -ForegroundColor Cyan
    try {
      & lua $m.Path 2>&1 | Out-Host
    }
    catch {
      #$_ | Out-File ~\watch.log -Append
      Write-Host $_ -ForegroundColor Red
    }
  }

  $s1 = Register-ObjectEvent -InputObject $watcher -EventName Changed -MessageData $msgData -Action $action
  $s2 = Register-ObjectEvent -InputObject $watcher -EventName Created -MessageData $msgData -Action $action
  $s3 = Register-ObjectEvent -InputObject $watcher -EventName Renamed -MessageData $msgData -Action $action
  $watcher.EnableRaisingEvents = $true

  Write-Host "Watching $path (subs: $($s1.Id),$($s2.Id),$($s3.Id))" -ForegroundColor Green
  #Write-Host "Press Ctrl+C to stop..." -ForegroundColor Yellow

  try { while ($true) { Start-Sleep -Seconds 1 } }
  finally {
    $watcher.EnableRaisingEvents = $false
    $watcher.Dispose()
    Unregister-Event -SubscriptionId $s1.Id -ErrorAction SilentlyContinue
    Unregister-Event -SubscriptionId $s2.Id -ErrorAction SilentlyContinue
    Unregister-Event -SubscriptionId $s3.Id -ErrorAction SilentlyContinue
  }
}

# Function Run-PSScript-Analyzer {
#   param(
#       [Parameter()]
#       [String]$path='.'
#   )
#   Invoke-ScriptAnalyzer -recurse -Path $path
# }

function Get-Dockfire-Family{
  param(
    [String[]]$fileNames=@('.dockerignore','Dockerfile','Compose.yml')
  )
  $filenames.foreach({if (!(test-path $_)) {new-item -Path $_ -ItemType File}})
}

function Get-Rust-Combinator-Cheatsheet{
  param(
    [ValidateSet('c','i','l','t','awjf','awrs')]
    [String]$key='c'
  )
  $combinators=@(
    [pscustomobject]@{Purpose='Transform success value';Option='map';Result='map'}
    [pscustomobject]@{Purpose='Transform with fallback';Option='map_or / map_or_else';Result='map_or / map_or_else'}
    [pscustomobject]@{Purpose='Chain fallible ops (flatten)';Option='and_then';Result='and_then'}
    [pscustomobject]@{Purpose='Recover on failure';Option='or / or_else';Result='or / or_else'}
    [pscustomobject]@{Purpose='Keep based on predicate';Option='filter';Result='-(use and_then)'}
    [pscustomobject]@{Purpose='Convert to Result';Option='ok_or / ok_or_else';Result='-'}
    [pscustomobject]@{Purpose='Peek for logging';Option='inspect';Result='inspect / inspect_err'}
    [pscustomobject]@{Purpose='Combine two';Option='zip, and, or';Result='and, or'}
    [pscustomobject]@{Purpose='Early return on failure';Option='?';Result='?'}
  )
  $iterators=@(
    [pscustomobject]@{Method='iter()';Receiver='&self';Yields='&T';Ownership='Borrow immutable'}
    [pscustomobject]@{Method='iter_mut()';Receiver='&mut self';Yields='&mut T';Ownership='Borrow mutable'}
    [pscustomobject]@{Method='into_iter()';Receiver='self';Yields='T';Ownership='moved, to owned'}
  )
  $lifetime=@(
    [pscustomobject]@{Concept='distinc for all';Example='fn first<''a, ''b>(x: &''a str, y: &''b str) -> &''a str {..}'}
    [pscustomobject]@{Concept='one for all';Example='fn longest<''a>(x: &''a str, y: &''a str) -> &''a str {..}'}
    [pscustomobject]@{Concept='self for all';Example='struct Fahrenheit<''a> {lable: &''a str,} impl<''a> Fahrenheit<''a> {fn lable(&''a self) -> &''a str {..}}'}
    [pscustomobject]@{Concept='''a:''b';Example='''a outlives ''b'}
    [pscustomobject]@{Concept='T:''a';Example='T contains references outlives ''a, not means T is reference'}
    [pscustomobject]@{Concept='T:''static';Example='T is an owned type + any static reference'}
  )
  $trait=@(
    [pscustomobject]@{Method='trait Tr: SuperTrait{..}';Result='bound user-defined trait'}
    [pscustomobject]@{Method='trait Tr<T>{..}';Result='generic user-defined trait, blanket impl'}
  )
  $actixwebJF=@(
    [pscustomobject]@{Name='web::Json<T>';ContentType='application/json';CurlFlag='-d ''{"k":"v"}''(pwsh[\"])';BodyFormat='{"name":"alice","age":42}';FileContent='-d "@payload.json"'}
    [pscustomobject]@{Name='web::Form<T>';ContentType='application/x-www-form-urlencoded';CurlFlag='-d "k=v&k2=v2"';BodyFormat='name=alice&age=42';FileContent='-d "@payload.txt"'}
  )
  $actixwebRS=@(
    [pscustomobject]@{Name='web::resource("/x")';Concept='One path, multiple methods';HandleRequest='Yes(via its routes)';CanContain='.route(),.name(),.guard()';Example='web::resource("/users/{id}").route(web::get().to(get_user)).route(web::delete().to(delete_user))'}
    [pscustomobject]@{Name='web::scope("/x")';Concept='A prefix namespace';HandleRequest='No(delegates to children)';CanContain='.route(),.service(resource),service(scope)';Example='web::scope("/api").route("/users",web::get().to(list))'}
  )

  $labels=[ordered]@{c='combinators';i='iterators';l='lifetime';t='trait';awJF='actixwebJF';awRS='actixwebRS'}
  $map=[ordered]@{c=$combinators;i=$iterators;l=$lifetime;t=$trait;awJF=$actixwebJF;awRS=$actixwebRS}

  $label=$labels.$key
  Write-Host "$label in Rust" -ForegroundColor Green
  $map.$key | format-table
}

function Disable-Taskbar-Flashing{
  Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name "ForegroundFlashCount" -Value 1
}

function New-LocalCert {
    param(
        [Parameter(Mandatory)]
        [string[]]$Names,

        [string]$CertFile = "cert.pem",
        [string]$KeyFile  = "key.pem",
        [string]$OutDir   = (Get-Location).Path
    )

    $certPath = Join-Path $OutDir $CertFile
    $keyPath  = Join-Path $OutDir $KeyFile

    $args = @("-cert-file", $certPath, "-key-file", $keyPath) + $Names
    mkcert @args

    Write-Host "✔ Certificate: $certPath" -ForegroundColor Green
    Write-Host "✔ Key:         $keyPath"  -ForegroundColor Green
}

function Install-LocalCA {
    $caRoot = (mkcert -CAROOT).Trim()
    Write-Host "CA root: $caRoot"
    mkcert -install
}

function Modify-Readline-History{
  code (Get-PSReadLineOption).HistorySavePath
}

function Get-Postgres-ConnectionString {
    param(
        [string]$EnvFile = ".env"
    )

    if (-not (Test-Path $EnvFile)) {
        throw "Env file not found: $EnvFile (resolved to '$((Resolve-Path -ErrorAction SilentlyContinue $EnvFile).Path)')"
    }

    $envVars = @{}
    Get-Content $EnvFile | ForEach-Object {
        $line = $_.Trim()
        if ($line -and -not $line.StartsWith('#')) {
            $name, $value = $line -split '=', 2
            $value = $value.Trim().Trim('"').Trim("'")
            $envVars[$name.Trim()] = $value
        }
    }

    $pgUser  = $envVars['POSTGRES_USER']
    $pgPass  = [uri]::EscapeDataString($envVars['POSTGRES_PASSWORD'])
    $pgHost  = if ($envVars['POSTGRES_HOST'] -eq "db") { "localhost" } else { $envVars['POSTGRES_HOST'] }
    $pgPort  = $envVars['POSTGRES_PORT']
    $pgDb    = $envVars['POSTGRES_DB']

    return "postgresql://${pgUser}:${pgPass}@${pgHost}:${pgPort}/${pgDb}"
}

function Invoke-Api-With-Curl {
  param(
    [Parameter(Mandatory)][string]$Url,
    [Parameter(Mandatory)][string]$Body,
    [ValidateSet(
      "text/plain",
      "application/json",
      "application/xml",
      "application/x-www-form-urlencoded",
      "multipart/form-data"
    )][string]$ContentType = "application/x-www-form-urlencoded",
    [ValidateSet("GET","POST","PUT","PATCH","DELETE")][string]$Method = "POST"
  )

  if ($Body.StartsWith("@")) {
    curl.exe -X $Method $Url -H "Content-Type: $ContentType" --data-binary "`"$Body`""
  } else {
    curl.exe -X $Method $Url -H "Content-Type: $ContentType" -d $Body
  }
}

function Inspect-Docker-Container-ENV {
  param([string]$Service='api')
  docker inspect $(docker compose ps -q $Service) --format '{{json .Config.Env}}'
}

function Generate-Redis-CacheService{
  param([string]$dst='./src/')
  $CacheService = @"
use redis::AsyncCommands;

#[derive(Clone)]
pub struct CacheService {
    pool: deadpool_redis::Pool,
    prefix: String,
    default_ttl: u64,
}
#[allow(unused)]
impl CacheService {
    pub fn new(url: &str, prefix: &str, default_ttl: u64) -> Self {
        let cfg = deadpool_redis::Config::from_url(url);
        let pool = cfg
            .create_pool(Some(deadpool_redis::Runtime::Tokio1))
            .expect(`"failed to create Redis pool`");
        Self {
            pool,
            prefix: prefix.into(),
            default_ttl,
        }
    }

    fn key(&self, key: &str) -> String {
        format!(`"{}:{}`", self.prefix, key)
    }

    /// Returns `None` on cache miss or if Redis is unreachable.
    pub async fn get(&self, key: &str) -> Option<String> {
        let mut conn = self.pool.get().await.ok()?;
        conn.get::<_, Option<String>>(self.key(key))
            .await
            .ok()
            .flatten()
    }

    /// Sets a value with an optional TTL override. Returns false if Redis is down.
    pub async fn set(&self, key: &str, value: &str, ttl: Option<u64>) -> bool {
        let mut conn = match self.pool.get().await {
            Ok(c) => c,
            Err(_) => return false,
        };
        let ttl = match ttl {
            Some(t) => t,
            None => self.default_ttl + rand::random_range(0..=30),
        };
        conn.set_ex::<_, _, ()>(self.key(key), value, ttl)
            .await
            .is_ok()
    }

    /// Deletes a key. Returns false if Redis is down.
    pub async fn delete(&self, key: &str) -> bool {
        let mut conn = match self.pool.get().await {
            Ok(c) => c,
            Err(_) => return false,
        };
        conn.del::<_, usize>(self.key(key)).await.is_ok()
    }

    pub async fn get_or_load<F, Fut>(&self, key: &str, loader: F) -> Option<String>
    where
        F: FnOnce() -> Fut,
        Fut: std::future::Future<Output = Option<String>>,
    {
        if let Some(cached) = self.get(key).await {
            return Some(cached);
        }
        let value = loader().await?;
        let _ = self.set(key, &value, None).await;
        Some(value)
    }

    pub async fn ttl(&self, key: &str) -> Option<u64> {
        let mut conn = match self.pool.get().await {
            Ok(c) => c,
            Err(_) => return None,
        };
        let secs: i64 = conn.ttl(self.key(key)).await.ok()?;
        match secs {
            -2 => None,    // key doesn't exist
            -1 => Some(0), // key exists, no expiry set
            n if n > 0 => Some(n as u64),
            _ => None, // shouldn't happen, but be safe
        }
    }
}
"@
  if (Test-Path $dst) {
    New-Item -Path "$dst/sharedis.rs" -Force -ItemType File -Value $CacheService | Out-Null
  }
}


Set-Alias gcw Get-Cargo-Workspace
Set-Alias spm Set-ProcMacro-Config
Set-Alias rcc Run-Cargo-Clippy
Set-Alias rcw Run-Cargo-Watch
# Set-Alias rpa Run-PSScript-Analyzer
Set-Alias wls Watch-Lua-Script
Set-Alias gdf Get-Dockfire-Family
Set-Alias grcc Get-Rust-Combinator-Cheatsheet
Set-Alias gpcs Get-Postgres-ConnectionString
Set-Alias iawc Invoke-Api-With-Curl