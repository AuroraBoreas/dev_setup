# $host.ui.RawUI.WindowTitle = "🐱‍🚀🚀🌔"
# module
# Install-Module PSReadLine -Repository PSGallery -Scope CurrentUser -Force

# install NERD font
# oh-my-posh font install --user 0xProto
# oh-my-posh scheme: material, jblab_2021, larserikfinholt, json
# ---------------------------------------------------------------
& ([ScriptBlock]::Create((oh-my-posh init pwsh --config "$env:POSH_THEMES_PATH\clean-detailed.omp.json" --print) -join "`n"))

# permanent user-alias, 20231216 @ZL
# Python Make. [deprecated(in 2025. using uv instead)]
# ---------------------------------------------------------------
function Create-Python-Venv {
  param(
    [Parameter(Mandatory)]
    [String]$projectName
  )
  if (!(Test-Path $projectName)) {
    New-Item $projectName -ItemType Directory | Out-Null
    Set-Location $projectName
    python -m venv .venv
    Write-Host "project at: $projectName" -ForegroundColor Green
  } else {
    Write-Host "failed to create project: $projectName" -ForegroundColor -Red
  }
}
function Activate-Python-Venv {
  if ([System.Environment]::OSVersion.VersionString -like '*Unix*') {source .venv/bin/activate} else {.venv\scripts\activate}
}
function Freeze-Python-Dependencies {pip freeze > requirements.txt}
# function Get-Dependencies {param([string]$src="~/.django/requirements.txt",[string]$dst=".") Copy-Item -Path $src -Destination $dst -Force}
# function Install-Dependencies {param([string]$Name="requirements.txt") pip install -r $Name}
# function Uninstall-Dependencies {param([string]$Name="requirements.txt") pip uninstall -r $Name -y}
# function Profile-Python-App {param([Parameter(Mandatory=$true)][string]$App) python -m cProfile -s cumtime $App}
# function Update-Pip {python -m pip install --upgrade pip}
# function Get-Pytest {
#   param([string]$src="~/.django/python-testing-with-pytest.zip",[string]$dst=".")
#   Expand-Archive -Path $src -DestinationPath $dst -Force
# }
# function Generate-Pyproject-Structure {
#   param([Parameter(Mandatory=$true)][string]$ProjectName,[Parameter(Mandatory=$true)][string]$PackageName)
#   $dst = "$ProjectName/src/$PackageName"
#   mkdir $dst -Force
#   New-Item $dst/__init__.py -Force
#   New-Item $dst/__main__.py -Force
# }

Set-Alias getvenv Create-Python-Venv
Set-Alias source Activate-Python-Venv
Set-Alias freeze Freeze-Python-Dependencies
# Set-Alias getRqm Get-Dependencies
# Set-Alias rqm Install-Dependencies
# Set-Alias profile Profile-Python-App
# Set-Alias pipu Update-Pip
# Set-Alias pipc Uninstall-Dependencies
# Set-Alias getpytest Get-Pytest
# Set-Alias getpyproject Generate-Pyproject-Structure

# project templates !TODO, 20240616. [deprecated(in 2025. using uv instead)]
# ---------------------------------------------------------------
# function Get-Cookiecutter-Django {
#   param([string]$src="~/.django/cookiecutter-django.zip")
#   cookiecutter $src
# }
# function Get-Bootstrap-Template {
#   param([string]$src="~/.django/bootstrap-template-5.0.zip",[string]$dst=".")
#   Expand-Archive -Path $src -DestinationPath $dst -Force
# }

# function Get-Frontend-Playground {
#   param([string]$src="~/.django/frontend-playground-1.0.zip",[string]$dst=".")
#   Expand-Archive -Path $src -DestinationPath $dst -Force
# }
# function Get-Django-Dockerized {
#   param([string]$src="~/.django/django-dockerized-1.0.zip",[string]$dst=".")
#   Expand-Archive -Path $src -DestinationPath $dst -Force
# }

# Set-Alias getCCDJ Get-Cookiecutter-Django
# Set-Alias getBST Get-Bootstrap-Template
# Set-Alias getFrontend Get-Frontend-Playground
# Set-Alias getDjDk Get-Django-Dockerized

# Django Make, 20240427 [deprecated(in 2025. using ASP.NET instead)]
# ---------------------------------------------------------------
# function Django-Admin-Createproject {param([Parameter(Mandatory=$true)][string]$Name) django-admin startproject $Name}
# function Django-Admin-Startapp {param([Parameter(Mandatory=$true)][string]$Name) django-admin startapp $Name}
# function Python-Manage-Runserver {python manage.py runserver}
# function Python-Manage-Runserver-Dev {param([string]$IP="0.0.0.0:8000") python manage.py runserver $IP}
# function Python-Manage-Makemigrations {
#   param([string]$Name=$null)
#   if ([string]::IsNullOrEmpty($Script)) {python manage.py makemigrations} else {python manage.py makemigrations $Name}
# }
# function Python-Manage-Migrate {
#   param([string]$Name=$null)
#   if ([string]::IsNullOrEmpty($Script)) {python manage.py migrate} else {python manage.py migrate $Name}
# }
# function Python-Manage-Createsuperuser {python manage.py createsuperuser}
# function Python-Manage-Test {
#   param([string]$App=$null)
#   if ($App -eq $null) {python manage.py test} else {python manage.py test $App}
# }
# function Python-Manage-Runscript {param([Parameter(Mandatory=$true)][string]$Name) python manage.py runscript $Name}
# function Python-Upgrate-Pip-Install-Django {pip install django}
# function Python-Manage-Command {
#   param([string]$Script,[int]$n=10)
#   if (!([string]::IsNullOrEmpty($Script))) {python manage.py $Script $n} else { Write-Host "FileNotFoundError: $Script" }
# }
# function Python-Manage-Inspect {param([string]$Name="models.py") python manage.py inspectdb > $Name}
# function Python-Manage-Shell {python manage.py shell_plus}
# function Python-Manage-Check {python manage.py check --deploy}
# function Profile-Django-Tests {
#   param([Parameter(Mandatory=$true)][string]$App,[bool]$Out=$false)
#   if ($Out) {python -m cProfile -s cumtime manage.py test $App 2>&1 > prof.txt}
#   else {
#     if ([System.Environment]::OSVersion.VersionString -like "*Unix*") {python -m cProfile -s cumtime manage.py test $App 2>&1 | less}
#     else {python -m cProfile -s cumtime manage.py test $App 2>&1 | more}
#   }
# }

# Set-Alias djsp Django-Admin-Createproject
# Set-Alias djsa Django-Admin-Startapp
# Set-Alias djrs Python-Manage-Runserver
# Set-Alias djrsdev Python-Manage-Runserver-Dev
# Set-Alias djmm Python-Manage-Makemigrations
# Set-Alias djmg Python-Manage-Migrate
# Set-Alias djcs Python-Manage-Createsuperuser
# Set-Alias djtest Python-Manage-Test
# Set-Alias djcmd Python-Manage-Command
# Set-Alias djrun Python-Manage-Runscript
# Set-Alias getdj Python-Upgrate-Pip-Install-Django
# Set-Alias djinspect Python-Manage-Inspect
# Set-Alias djshell Python-Manage-Shell
# Set-Alias djcheck Python-Manage-Check
# Set-Alias djprof Profile-Django-Tests


# C/C++ Make, 20240710
# ---------------------------------------------------------------
function Get-Preprocess {param([string]$src='main.c') gcc -E $src}
function Get-Assembly {param([string]$src='main.c') gcc -S $src}
function Get-MachineCode {param([string]$src='main.c') gcc -c $src}
function Get-Executable {param([string]$src='main.c', [string]$dst='a') gcc $src -o $dst}
function Get-DumpTreeGraph {param([string]$src='main.c') gcc -fdump-tree-all-graph -g $src}
function Get-ObjDump {param([string]$src='main.o') objdump $src}
function Get-ld {param([string]$src) ld $src}


Set-Alias pre Get-Preprocess
Set-Alias asm Get-Assembly
Set-Alias cmc Get-MachineCode
Set-Alias bin Get-Executable
Set-Alias viz Get-DumpTreeGraph
Set-Alias obj Get-ObjDump


# Tutorial Video Make, 20240821. [deprecated(in 2025. worthless)]
# ---------------------------------------------------------------
# function Get-Tutorial-Video-Template {
#   param([string]$src="~/.django/tutorial-creator.zip",[string]$dst=".")
#   Expand-Archive -Path $src -DestinationPath $dst -Force
# }

# function Create-Tutorial-Video-Workspace {
#   param([Parameter(Mandatory=$true)][string]$DirName,[string]$what="Python-Tutorial-")
#   Get-Tutorial-Video-Template
#   mkdir $DirName -Force
#   $NewName = "$DirName-$What.pptx"
#   rename-item "./template.pptx" $NewName
#   move-item -Force $NewName $DirName
#   cd $DirName
#   new-item "story.md" -Force
#   new-item "main.py" -Force
#   "谢谢大家的观看。我们下次再见！欢迎点赞收藏转发，谢谢！" | Out-File -FilePath "storyteller.txt"
#   cd ..
# }

# Set-Alias getTV Create-Tutorial-Video-Workspace


# The following commands work only in Sonic PC(portable version), comment them out if error occurs, 20240124 @ZL
# VSCode
# ---------------------------------------------------------------
# function Open-VSCode {param([string]$path=".") C:\D\DevEnv\VSCode-win32-x64-1\Code.exe -n $path}
# Set-Alias code Open-VSCode

# Mathematic Make [deprecated(in 2025. worthless)]
# ---------------------------------------------------------------
# function Get-Math-Calculus {Code -n D:\Win-Mac-Share\2023_Assembly\20231115_Calculus_and_Analytic_Geometry}
# Set-Alias cg Get-Math-Calculus
# function Get-Math-LinearAlgebra {Code -n D:\Win-Mac-Share\2023_Assembly\20240123_LA}
# Set-Alias la Get-Math-LinearAlgebra
# function Get-Practical-ML {Code -n D:\Win-Mac-Share\2023_Assembly\20230707_Practical_Machine_Learning_with_Python}
# Set-Alias ml Get-Practical-ML
# function Get-Math-Discrete {Code -n D:\Win-Mac-Share\2023_Assembly\20240316_DiscreteMath}
# Set-Alias dm Get-Math-Discrete
# function Get-Math-AbstractAlgebra {Code -n D:\Win-Mac-Share\2023_Assembly\20240404_AbstractAlgebra}
# Set-Alias aa Get-Math-AbstractAlgebra
# function Get-The-Art-Of-Electronics {Code -n D:\Win-Mac-Share\2023_Assembly\20240725_the_art_of_electronics}
# Set-Alias aoe Get-The-Art-Of-Electronics
# function Get-Design-of-Experiments {Code -n D:\Win-Mac-Share\2023_Assembly\20140801_DOE}
# Set-Alias doe Get-Design-of-Experiments

# DevEnvBackup [deprecated(in 2025. macpro dead)]
# ---------------------------------------------------------------
function Sync-VSCode-Zed-RustCodeSnippet{
  param(
    [string]$srcDir='~/AppData/Roaming/Code/User/snippets',
    [string]$dstDir='~/AppData/Roaming/Zed/snippets'
  )
  if (-not ((Test-Path $srcDir) -and (Test-Path $dstDir))) { return }
  $rustJson = "rust.json"
  $tomlJson = "toml.json"
  $srcFile = "$srcDir/$rustJson"
  if (Test-Path $srcFile) {Copy-Item -Path $srcFile -Destination "$dstDir/$rustJson" -Force}
  $srcFile = "$srcDir/$tomlJson"
  if (Test-Path $srcFile) {Copy-Item -Path $srcFile -Destination "$dstDir/$tomlJson" -Force}
}

function Backup-Dev-Env-Settings {
  $root = '~'
  $buDir="$root\BU-dev-101\"
  If (!(Test-Path $buDir)) {mkdir $buDir | Out-Null}

  # --- vscode ---
  $dst="$buDir\01-vscode"
  If (!(Test-Path $dst)) {mkdir $dst | Out-Null}
  $editorName = 'Code'
  $srcPaths=(
    "$root\AppData\Roaming\$editorName\User\keybindings.json",
    "$root\AppData\Roaming\$editorName\User\settings.json",
    "$root\AppData\Roaming\$editorName\User\snippets\"
  )
  ForEach($SrcPath in $srcPaths) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}
  $extensions = code --list-extensions
  $extensions | Out-File -FilePath "$dst\vscode-extensions.txt" -Encoding utf8

  # --- windows terminal ---
  $dst="$buDir\02-windows-terminal\"
  If (!(Test-Path $dst)) {mkdir $dst | Out-Null}
  $srcPaths=(
    "$root\AppData\Local\Packages\Microsoft.WindowsTerminal_8wekyb3d8bbwe\LocalState\settings.json",
    "$root\Documents\WindowsPowerShell\Microsoft.PowerShell_profile.ps1"
  )
  ForEach($SrcPath in $srcPaths) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}

  # --- blender ---
  # $dst="$buDir\05-utilities\MyPkg\blender\preferences\user_config"
  # If (!(Test-Path $dst)) {mkdir $dst}
  # $SrcPath="$root\AppData\Roaming\Blender Foundation\Blender\4.1\config\userpref.blend"
  # If (Test-Path $SrcPath) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}

  # --- vs ---
  $dst="$buDir\03-vs"
  If (!(Test-Path $dst)) {mkdir $dst | Out-Null}
  $SrcPath="$root\Documents\Visual Studio 2022\Code Snippets"
  If (Test-Path $SrcPath) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}
  $SrcPath="C:\ProgramE\Program\Microsoft Visual Studio\Common7\IDE\VC\Snippets"
  If (Test-Path $SrcPath) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}

  # --- idea ---
  # manually bu

  # --- zed ---
  $dst="$buDir\05-zed"
  If (!(Test-Path $dst)) {mkdir $dst | Out-Null}
  $editorName = 'Zed'
  $srcPaths=(
    "$root\AppData\Roaming\$editorName\keymap.json",
    "$root\AppData\Roaming\$editorName\settings.json",
    "$root\AppData\Roaming\$editorName\snippets\"
  )
  ForEach($srcPath in $srcPaths) {Copy-Item -Path $srcPath -Destination $dst -Recurse -Force}

  # --- toolkit ---
  $dst=$buDir
  $folderPath='C:\ProgramE\Program\'
  If (Test-Path $folderPath) {
    $subfolders = Get-ChildItem -Path $folderPath -Directory
    $subfolders | Select-Object Name | Export-Csv -Path "$dst\devEnv.csv" -NoTypeInformation
  }

  $src=$buDir
  $timeStamp = Get-Date -Format 'yyyyMMddHHmm'
  $dst="$root\$timeStamp-BU-dev-101.zip"
  Compress-Archive -Path $src -DestinationPath $dst -Force
}

function Update-VSCode-UserSnippet {
  param([string]$path="$root\BU-dev-101\01-vscode\snippets\")
  $dst="$root\AppData\Roaming\Code\User"
  if (Test-Path $dst) {
    Copy-Item -Path $path -Destination $dst -Force -Recurse
  }
}

function Backup-Obsidian-Projects {
  $root = '~'
  $buDir="$root\BU-Obsidian-Projects\"
  If (!(Test-Path $buDir)) {mkdir $buDir | Out-Null}

  # --- obsidian ---
  $dst="$buDir\01-obsidian"
  If (!(Test-Path $dst)) {mkdir $dst | Out-Null}
  $srcPath='~\ObsidianProjects\Vault'
  If (Test-Path $SrcPath) {Copy-Item -Path $SrcPath -Destination $dst -Recurse -Force}
  $excluded="$dst\Vault\.obsidian"
  If (Test-Path $excluded) {Remove-Item -force -recurse $excluded}

  $src=$buDir
  $timeStamp = Get-Date -Format 'yyyyMMddHHmm'
  $dst="$root\$timeStamp-BU-Obsidian-Projects.zip"
  Compress-Archive -Path $src -DestinationPath $dst -Force
}

function Backup-DevEnv-And-ObsidianProjects{
  param([bool]$obs=$false)
  Sync-VSCode-Zed-RustCodeSnippet
  Backup-Dev-Env-Settings
  if ($obs) {Backup-Obsidian-Projects}
  cd "~"
  start "."
}

function Update-Dev-Env-Settings {
  $zipFileName="$root\Downloads\BU-dev-101.zip"
  $dstFolder="$root\BU-dev-101"
  if (Test-Path $dstFolder) {Remove-Item -Path $dstFolder -Force -Recurse}
  if (Test-Path $zipFileName) {
    Expand-Archive -Path $zipFileName -DestinationPath "~\" -Force
    Update-VSCode-UserSnippet
    Update-Django-Template
    Remove-Item -Path $zipFileName -Force -Recurse
  }
  else {Write-Host 'FileNotFoundError: `BU-dev-101.zip` in Downloads..'}
}

Set-Alias bu Backup-DevEnv-And-ObsidianProjects
Set-Alias up Update-Dev-Env-Settings

# Cargo workspace[stable(since="0.1.0")]
# ---------------------------------------------------------------
function Get-Cargo-Workspace {
  param(
    [Parameter()]
    [String]$root='~/rustprojects',
    [String]$ProjectName='my-project'
  )
  $dst = "$root/$ProjectName/"
  If (!(Test-Path $dst)) {mkdir $dst | Out-Null}
  $configFile = 'Cargo.toml'
  $config = '[workspace]`r`nresolver=`"`3`"`r`n'
  New-Item -Path $dst/$configFile -Force -ItemType File -Value $config | Out-Null
  Write-Host "Workspace at: $dst" -ForegroundColor Green
}

#[deprecated. use cargo clippy -- -D clippy::pedantic -D clippy::nursery]
# function Inject-Clippy-Config-Into-Cargo-Toml {
#   $configFile = "Cargo.toml"
#   $Config ="`r`n[lints.clippy]`r`npedantic = { level = `"`deny`", priority = -1 }`r`nnursery = { level = `"`deny`", priority = -1 }`r`nunwrap_used = `"`deny`"`r`nexpect_used = `"`deny`"`r`nindexing_slicing = `"`deny`"`r`narithmetic_side_effects = `"`deny`"`r`nunreachable = `"`deny`"`r`nunimplemented = `"`deny`"`r`nunchecked_time_subtraction = `"`deny`"`r`ntodo = `"`deny`"`r`nstring_slice = `"`deny`"`r`npanic_in_result_fn = `"`deny`"`r`npanic = `"`deny`"`r`nexit = `"`deny`"`r`nas_conversions = `"`deny`""
#   $Pwd = pwd
#   If (Test-Path $configFile) {
#     Add-Content -Path $configFile -Value $Config
#   } else {
#     Write-Warning "Failed. $configFile is not found in $Pwd"
#   }
# }

# function Set-Clippy-Tomal {
#   $configFile = "clippy.toml"
#   $Config="allow-unwrap-in-tests = true`r`nallow-expect-in-tests = true`r`nallow-panic-in-tests = true`r`nallow-indexing-slicing-in-tests = true`r`n"
#   New-Item -Path $configFile -Force -ItemType File -Value $Config | Out-Null
# }

# function Init-Cargo-Clippy {
#   try {
#     cargo clippy -- -D clippy::pedantic -D clippy::nursery
#   } catch {
#     Write-Host "Cargo not found." -ForegroundColor Red
#   }
# }

# User-defined function for LSP or shortcuts[stable(since="0.1.0")]
# ---------------------------------------------------------------

function Run-Cargo-Clippy {
  cargo clippy -- -D clippy::pedantic -D clippy::nursery
}

function Run-Cargo-Watch {
  param(
    [Parameter(Mandatory)]
    [String]$src
  )
  if (Test-Path($src)) {cargo watch -q -c -w $src -x run}
}

function Update-Powershell-PackageManager {
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

  $names = @('PowerShellGet', 'PackageManagement', 'Microsoft.PowerShell.PSResourceGet')
  Get-Module -Name $names -ListAvailable
  Find-Module -Name $names -Repository PSGallery

  Install-Module PowerShellGet -Repository PSGallery -Force -AllowClobber
  Install-Module Microsoft.PowerShell.PSResourceGet -Repository PSGallery
}

function Watch-Lua-Script {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$true)]
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [string]$path
  )
  $path = (Resolve-Path $path).Path
  $directory = Split-Path -Path $path -Parent
  $filename = Split-Path -Path $path -Leaf

  $watcher = New-Object System.IO.FileSystemWatcher
  $watcher.Path = $directory
  $watcher.Filter = $filename
  $watcher.NotifyFilter = [System.IO.NotifyFilters]::LastWrite -bor [System.IO.NotifyFilters]::FileName -bor [System.IO.NotifyFilters]::CreationTime
  $watcher.IncludeSubdirectories = $false

  $state = [hashtable]::Synchronized(@{ LastRun = [datetime]::MinValue })
  $msgData = @{ Path = $path; Debounce = 2; State = $state }

  $action = {
    $m = $Event.MessageData
    $now = Get-Date
    if (($now - $m.State.LastRun).TotalSeconds -lt $m.Debounce) { return }
    $m.State.LastRun = $now

    $evt = $Event.SourceEventArgs
    $msg = "$(Get-Date -Format 'HH:mm:ss') $($evt.ChangeType) $($evt.FullPath)"
    #$msg | Out-File ~\watch.log -Append
    Write-Host $msg -ForegroundColor Cyan
    try {
      & lua $m.Path 2>&1 | Out-Host
    }
    catch {
      #$_ | Out-File ~\watch.log -Append
      Write-Host $_ -ForegroundColor Red
    }
  }

  $s1 = Register-ObjectEvent -InputObject $watcher -EventName Changed -MessageData $msgData -Action $action
  $s2 = Register-ObjectEvent -InputObject $watcher -EventName Created -MessageData $msgData -Action $action
  $s3 = Register-ObjectEvent -InputObject $watcher -EventName Renamed -MessageData $msgData -Action $action
  $watcher.EnableRaisingEvents = $true

  Write-Host "Watching $path (subs: $($s1.Id),$($s2.Id),$($s3.Id))" -ForegroundColor Green
  #Write-Host "Press Ctrl+C to stop..." -ForegroundColor Yellow

  try { while ($true) { Start-Sleep -Seconds 1 } }
  finally {
    $watcher.EnableRaisingEvents = $false
    $watcher.Dispose()
    Unregister-Event -SubscriptionId $s1.Id -ErrorAction SilentlyContinue
    Unregister-Event -SubscriptionId $s2.Id -ErrorAction SilentlyContinue
    Unregister-Event -SubscriptionId $s3.Id -ErrorAction SilentlyContinue
  }
}

# function Run-PSScript-Analyzer {
#   param(
#       [Parameter()]
#       [String]$path='.'
#   )
#   Invoke-ScriptAnalyzer -recurse -Path $path
# }

function Get-Dockfire-Family{
  param(
    [String[]]$fileNames=@('.dockerignore','Dockerfile','Compose.yml')
  )
  $filenames.foreach({if (!(test-path $_)) {new-item -Path $_ -ItemType File | Out-Null}})
}

function Get-Rust-Combinator-Cheatsheet{
  param(
    [ValidateSet('c','i','l','t','awjf','awrs','pt','ro')]
    [String]$key='c'
  )
  $combinators=@(
    [pscustomobject]@{Purpose='Transform success value';Option='map';Result='map'}
    [pscustomobject]@{Purpose='Transform with fallback';Option='map_or / map_or_else';Result='map_or / map_or_else'}
    [pscustomobject]@{Purpose='Chain fallible ops (flatten)';Option='and_then';Result='and_then'}
    [pscustomobject]@{Purpose='Recover on failure';Option='or / or_else';Result='or / or_else'}
    [pscustomobject]@{Purpose='Keep based on predicate';Option='filter';Result='-(use and_then)'}
    [pscustomobject]@{Purpose='Convert to Result';Option='ok_or / ok_or_else';Result='-'}
    [pscustomobject]@{Purpose='Peek for logging';Option='inspect';Result='inspect / inspect_err'}
    [pscustomobject]@{Purpose='Combine two';Option='zip, and, or';Result='and, or'}
    [pscustomobject]@{Purpose='Early return on failure';Option='?';Result='?'}
  )
  $iterators=@(
    [pscustomobject]@{Method='iter()';Receiver='&self';Yields='&T';Ownership='Borrow immutable'}
    [pscustomobject]@{Method='iter_mut()';Receiver='&mut self';Yields='&mut T';Ownership='Borrow mutable'}
    [pscustomobject]@{Method='into_iter()';Receiver='self';Yields='T';Ownership='moved, to owned'}
  )
  $lifetime=@(
    [pscustomobject]@{Concept='distinc for all';Example='fn first<''a, ''b>(x: &''a str, y: &''b str) -> &''a str {..}'}
    [pscustomobject]@{Concept='one for all';Example='fn longest<''a>(x: &''a str, y: &''a str) -> &''a str {..}'}
    [pscustomobject]@{Concept='self for all';Example='struct Fahrenheit<''a> {lable: &''a str,} impl<''a> Fahrenheit<''a> {fn lable(&''a self) -> &''a str {..}}'}
    [pscustomobject]@{Concept='''a:''b';Example='''a outlives ''b'}
    [pscustomobject]@{Concept='T:''a';Example='T contains references outlives ''a, not means T is reference'}
    [pscustomobject]@{Concept='T:''static';Example='T is an owned type + any static reference'}
  )
  $trait=@(
    [pscustomobject]@{Method='trait Tr: SuperTrait{..}';Result='bound user-defined trait'}
    [pscustomobject]@{Method='trait Tr<T>{..}';Result='generic user-defined trait, blanket impl'}
  )
  $actixwebJF=@(
    [pscustomobject]@{Name='web::Json<T>';ContentType='application/json';CurlFlag='-d ''{"k":"v"}''(pwsh[\"])';BodyFormat='{"name":"alice","age":42}';FileContent='-d "@payload.json"'}
    [pscustomobject]@{Name='web::Form<T>';ContentType='application/x-www-form-urlencoded';CurlFlag='-d "k=v&k2=v2"';BodyFormat='name=alice&age=42';FileContent='-d "@payload.txt"'}
  )
  $actixwebRS=@(
    [pscustomobject]@{Name='web::resource("/x")';Concept='One path, multiple methods';HandleRequest='Yes(via its routes)';CanContain='.route(),.name(),.guard()';Example='web::resource("/users/{id}").route(web::get().to(get_user)).route(web::delete().to(delete_user))'}
    [pscustomobject]@{Name='web::scope("/x")';Concept='A prefix namespace';HandleRequest='No(delegates to children)';CanContain='.route(),.service(resource),service(scope)';Example='web::scope("/api").route("/users",web::get().to(list))'}
  )
  $codeSnippetPlaceholderTramsform=@(
    [pscustomobject]@{Syntax='${1/(.*)/${1:/upcase}/}';Result='HELLO'}
    [pscustomobject]@{Syntax='${1/(.*)/${1:/downcase}/}';Result='hello'}
    [pscustomobject]@{Syntax='${1/(.*)/${1:/capitalize}/}';Result='Hello'}
    [pscustomobject]@{Syntax='${1/(.*)/${1:/camelcase}/}';Result='helloWorld (from hello_world)'}
    [pscustomobject]@{Syntax='${1/(.*)/${1:/pascalcase}/}';Result='HelloWorld (from hello_world)'}
  )
  $routers=@(
    [pscustomobject]@{Name='XGPON';IP_Addr='192.168.1.1';Admin='user';Pass='j8#nxza3';WIFI='CMCC-4Fj9';WPASS='mmkfgwph'}
    [pscustomobject]@{Name='RAX3000Z';IP_Addr='192.168.10.1';Admin='user';Pass='b7e4p@zu';WIFI='CMCC-aern-5G';WPASS='b7e4p2zu'}
  )

  $labels=[ordered]@{c='combinators';i='iterators';l='lifetime';t='trait';awJF='actixweb JF';awRS='actixweb RS';pt='CodeSnippet Placeholder Transform';ro='Routers'}
  $map=[ordered]@{c=$combinators;i=$iterators;l=$lifetime;t=$trait;awJF=$actixwebJF;awRS=$actixwebRS;pt=$codeSnippetPlaceholderTramsform;ro=$routers}

  $label=$labels.$key
  Write-Host "$label in Rust" -ForegroundColor Green
  $map.$key | format-table
}

function Disable-Taskbar-Flashing{
  Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name "ForegroundFlashCount" -Value 1
}

function New-LocalCert {
  param(
    [Parameter(Mandatory)]
    [string[]]$Names,

    [string]$CertFile = "cert.pem",
    [string]$KeyFile  = "key.pem",
    [string]$OutDir   = (Get-Location).Path
  )

  $certPath = Join-Path $OutDir $CertFile
  $keyPath  = Join-Path $OutDir $KeyFile

  $args = @("-cert-file", $certPath, "-key-file", $keyPath) + $Names
  mkcert @args

  Write-Host "✔ Certificate: $certPath" -ForegroundColor Green
  Write-Host "✔ Key:         $keyPath"  -ForegroundColor Green
}

function Install-LocalCA {
  $caRoot = (mkcert -CAROOT).Trim()
  Write-Host "CA root: $caRoot"
  mkcert -install
}

function Modify-Readline-History{
  code (Get-PSReadLineOption).HistorySavePath
}

function Get-Postgres-ConnectionString {
  param(
      [string]$EnvFile = ".env"
  )

  if (-not (Test-Path $EnvFile)) {
      throw "Env file not found: $EnvFile (resolved to '$((Resolve-Path -ErrorAction SilentlyContinue $EnvFile).Path)')"
  }

  $envVars = @{}
  Get-Content $EnvFile | ForEach-Object {
    $line = $_.Trim()
    if ($line -and -not $line.StartsWith('#')) {
      $name, $value = $line -split '=', 2
      $value = $value.Trim().Trim('"').Trim("'")
      $envVars[$name.Trim()] = $value
    }
  }

  $pgUser  = $envVars['POSTGRES_USER']
  $pgPass  = [uri]::EscapeDataString($envVars['POSTGRES_PASSWORD'])
  $pgHost  = if ($envVars['POSTGRES_HOST'] -eq "db") { "localhost" } else { $envVars['POSTGRES_HOST'] }
  $pgPort  = $envVars['POSTGRES_PORT']
  $pgDb    = $envVars['POSTGRES_DB']

  return "postgresql://${pgUser}:${pgPass}@${pgHost}:${pgPort}/${pgDb}"
}

function Invoke-Api-With-Curl {
  param(
    [Parameter(Mandatory)][string]$Url,
    [Parameter(Mandatory)][string]$Body,
    [ValidateSet(
      "text/plain",
      "application/json",
      "application/xml",
      "application/x-www-form-urlencoded",
      "multipart/form-data"
    )][string]$ContentType = "application/x-www-form-urlencoded",
    [ValidateSet("GET","POST","PUT","PATCH","DELETE")][string]$Method = "POST"
  )

  if ($Body.StartsWith("@")) {
    curl.exe -X $Method $Url -H "Content-Type: $ContentType" --data-binary "`"$Body`""
  } else {
    curl.exe -X $Method $Url -H "Content-Type: $ContentType" -d $Body
  }
}

function Inspect-Docker-Container-ENV {
  param([string]$Service='api')
  docker inspect $(docker compose ps -q $Service) --format '{{json .Config.Env}}'
}

function Open-PSReadline-History{
  code (Get-PSReadLineOption).HistorySavePath
}

function New-DotCargo-ConfigToml-SqlxOffline{
  param([string]$dst=".")
  if (-not (Test-Path "$dst/Cargo.toml")) {
    return
  }

  $dir = Join-Path $dst ".cargo"
  $file = Join-Path $dir "config.toml"
  if (-not (Test-Path $dir)) {
    New-Item -ItemType Directory -Path $dir | Out-Null
  }
  if (-not (Test-Path $file)) {
@"
[env]
SQLX_OFFLINE = "true"
"@ | Set-Content -Path $file -Encoding utf8 -Force
  }
}

function Monitor-Log-Redis{
  docker compose exec redis redis-cli MONITOR
}

function Monitor-Log-Postgres{
  # Inside psql (docker compose exec db psql -U admin -d test_db)
  # ALTER SYSTEM SET log_statement = 'all'; SELECT pg_reload_conf();
  # dupliate the console window
  # docker compose logs -f db
}

function New-DotEnv-Actix{
  param([string]$dst=".")
  if (-not (Test-Path "$dst/Cargo.toml")) {
    return
  }
@"
REDIS_URL=redis://127.0.0.1:6379
BIND_ADDR=127.0.0.1:8080
DATABASE_URL=postgresql://admin:admin@localhost:5432/test_db
POSTGRES_USER=admin
POSTGRES_PASSWORD=admin
POSTGRES_DB=test_db
DB_HOST=db
DB_PORT=5432
"@ | Set-Content '.env'
}

function New-DotEnv-Django{
  param([string]$dst=".")
  if (-not (Test-Path "$dst/Cargo.toml")) {
    return
  }
@"
REDIS_URL=redis://127.0.0.1:6379
BIND_ADDR=127.0.0.1:8080
POSTGRES_USER=admin
POSTGRES_PASSWORD=admin
POSTGRES_DB=test_db
DB_HOST=db
DB_PORT=5432
"@ | Set-Content '.env'
}

function New-Nginx-Config{
  param([string]$dst=".")
  $config = @"
limit_req_zone `$binary_remote_addr zone=api:10m rate=10r/s;
limit_conn_zone `$binary_remote_addr zone=conn_per_ip:10m;
proxy_cache_path /var/cache/nginx/cache levels=1:2 keys_zone=app_cache:10m max_size=1g inactive=60m use_temp_path=off;

server {
  listen 80;
  server_name _;

  # --- Connection limit: max 20 concurrent connections per IP ---
  limit_conn conn_per_ip 20;
  limit_conn_status 429;

  # --- Static files: cached ---
  location /static/ {
    proxy_cache app_cache;
    proxy_cache_valid 200 1h;
    proxy_cache_methods GET;
    add_header X-Cache-Status `$upstream_cache_status;

    proxy_pass http://api:8080;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP `$remote_addr;
    proxy_set_header X-Forwarded-For `$proxy_add_x_forwarded_for;
  }

  # --- API: no cache (Redis handles it) ---
  location / {
    # --- Rate limit: 10 req/s, burst 20 ---
    limit_req zone=api burst=20 nodelay;
    limit_req_status 429;

    proxy_pass http://api:8080;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP `$remote_addr;
    proxy_set_header X-Forwarded-For `$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto `$scheme;
  }
}
"@
  New-Item -Path "$dst/nginx.conf" -Force -ItemType File -Value $config | Out-Null
}

function New-Caddy-Config{
  param([string]$dst=".")
  $config = @"
http://localhost {
  reverse_proxy api:8080
}
"@
  New-Item -Path "$dst/Caddyfile" -Force -ItemType File -Value $config | Out-Null
}

function Get-PortUsage {
  netstat -ano | select-string "80"
}

function Run-WatchExec{
  param(
    [ValidateSet('rs','src')]
    [string]$x="rs"
  )
  watchexec -e $x -r cargo run
}

function New-SharedService{
  param([string]$dst='.')
  if (-not (Test-Path "$dst/Cargo.toml")) {
    Write-Host "Cargo.toml NotFound" -ForegroundColor Red
    return
  }
  $dir = "src/shared"
  New-Item -ItemType Directory -Path $dir -Force | Out-Null

@"
use redis::AsyncCommands;

#[derive(Clone)]
pub struct CacheService {
    pool: deadpool_redis::Pool,
    prefix: String,
    default_ttl: u64,
}
#[allow(unused)]
impl CacheService {
    pub fn new(url: &str, prefix: &str, default_ttl: u64) -> Self {
        let cfg = deadpool_redis::Config::from_url(url);
        let pool = cfg
            .create_pool(Some(deadpool_redis::Runtime::Tokio1))
            .expect("failed to create Redis pool");
        Self {
            pool,
            prefix: prefix.into(),
            default_ttl,
        }
    }

    fn key(&self, key: &str) -> String {
        format!("{}:{}", self.prefix, key)
    }

    pub async fn get(&self, key: &str) -> Option<String> {
        let mut conn = self.pool.get().await.ok()?;
        conn.get::<_, Option<String>>(self.key(key))
            .await
            .ok()
            .flatten()
    }

    pub async fn set(&self, key: &str, value: &str, ttl: Option<u64>) -> bool {
        let mut conn = match self.pool.get().await {
            Ok(c) => c,
            Err(_) => return false,
        };
        let ttl = match ttl {
            Some(t) => t,
            None => self.default_ttl + rand::random_range(0..=30),
        };
        conn.set_ex::<_, _, ()>(self.key(key), value, ttl)
            .await
            .is_ok()
    }

    pub async fn delete(&self, key: &str) -> bool {
        let mut conn = match self.pool.get().await {
            Ok(c) => c,
            Err(_) => return false,
        };
        conn.del::<_, usize>(self.key(key)).await.is_ok()
    }

    pub async fn get_or_load<F, Fut>(&self, key: &str, loader: F) -> Option<String>
    where
        F: FnOnce() -> Fut,
        Fut: std::future::Future<Output = Option<String>>,
    {
        if let Some(cached) = self.get(key).await {
            return Some(cached);
        }
        let value = loader().await?;
        let _ = self.set(key, &value, None).await;
        Some(value)
    }

    pub async fn ttl(&self, key: &str) -> Option<u64> {
        let mut conn = match self.pool.get().await {
            Ok(c) => c,
            Err(_) => return None,
        };
        let secs: i64 = conn.ttl(self.key(key)).await.ok()?;
        match secs {
            -2 => None,    // key doesn't exist
            -1 => Some(0), // key exists, no expiry set
            n if n > 0 => Some(n as u64),
            _ => None, // shouldn't happen, but be safe
        }
    }

    pub async fn invalidate_list(&self, list_key:&str) {
        self.delete(list_key).await;
    }
}
"@ | Set-Content "$dir/cache.rs"

@"
use std::{
    collections::HashMap,
    sync::{Arc, Mutex},
    time::Instant,
};

#[derive(Clone)]
pub struct RateLimiter {
    hits: Arc<Mutex<HashMap<String, (u32, Instant)>>>,
}
impl RateLimiter {
    pub fn new() -> Self {
        Self {
            hits: Arc::new(Mutex::new(HashMap::new())),
        }
    }
    pub fn check(&self, key: &str, limit: u32, window_secs: u64) -> bool {
        let mut map = self.hits.lock().unwrap();
        let now = std::time::Instant::now();
        let entry = map.entry(key.to_string()).or_insert((0, now));
        if now.duration_since(entry.1) > std::time::Duration::from_secs(window_secs) {
            *entry = (0, now);
        }
        entry.0 += 1;
        entry.0 <= limit
    }
}
impl Default for RateLimiter {
    fn default() -> Self {
        Self::new()
    }
}
"@ | Set-Content "$dir/rate_limit.rs"

@"
"@ | Set-Content "$dir/auth.rs"

@"
pub mod cache;
pub mod rate_limit;
pub mod auth;

pub use cache::CacheService;
pub use rate_limit::RateLimiter;
"@ | Set-Content "$dir/mod.rs"

  Write-Host "Created src/shared/ - add 'mod shared;' to main.rs" -ForegroundColor Green
}

function New-WebApi{
  param(
    [Parameter(Mandatory)]
    [string]$Name
  )
  if (-not (Test-Path "Cargo.toml")) {
    Write-Host "Cargo.toml NotFound" -ForegroundColor Red
    return
  }
  $Name = $($Name.ToLower())
  $dir = "src/$Name"
  New-Item -ItemType Directory -Path $dir -Force | Out-Null

  $Name = $Name.Substring(0,1).ToUpper() + $Name.Substring(1)

@"
pub mod error;
pub mod handler;
pub mod model;
pub mod service;

pub use error::${Name}Error;
pub use model::${Name};
pub use service::${Name}Service;

pub type ServiceResult<T> = Result<T, ${Name}Error>;

pub fn routes(cfg: &mut actix_web::web::ServiceConfig) {
    cfg.service(
        actix_web::web::scope("/$($Name.ToLower())s")
            // .route("/", actix_web::web::post().to(handler::create))
            // .route("/", actix_web::web::get().to(handler::list))
            // .route("/{id}", actix_web::web::get().to(handler::get))
            // .route("/{id}", actix_web::web::patch().to(handler::update))
            // .route("/{id}", actix_web::web::delete().to(handler::delete)),
    );
}
"@ | Set-Content "$dir/mod.rs"

@"
use crate::$($Name.ToLower())::{ServiceResult,${Name},${Name}Error};

#[derive(Clone)]
pub struct ${Name}Service {
    pool: sqlx::PgPool,
}

impl ${Name}Service {
    pub fn new(pool: sqlx::PgPool) -> Self { Self { pool } }
}
"@ | Set-Content "$dir/service.rs"

@"
use crate::{
    $($name.ToLower())::{${Name}, ${Name}Error},
    state::AppState,
};
use actix_web::{web, HttpResponse, Responder};

// --- DTOs ---

#[derive(Debug, serde::Deserialize)]
pub struct Create${Name}Schema {
  // pub title: String,
  // pub content: String,
}

#[derive(Debug, serde::Deserialize)]
pub struct Update${Name}Schema {
  // pub title: Option<String>,
  // pub content: Option<String>,
  // pub published: Option<bool>,
}

// --- Cache key helpers ---

fn cache_key(id: &uuid::Uuid) -> String {
    format!("note:{}", id)
}

const LIST_KEY: &str = "notes:all";
const TTL: u64 = 60;

// --- Handlers ---

pub async fn create(
    body: web::Json<Create${Name}Schema>,
    data: web::Data<AppState>,
) -> Result<impl Responder, ${Name}Error> {
    HttpResponse::Ok().json("todo")
}

pub async fn list(data: web::Data<AppState>) -> Result<impl Responder, ${Name}Error> {
    HttpResponse::Ok().json("todo")
}

pub async fn get(
    id: web::Path<uuid::Uuid>,
    data: web::Data<AppState>,
    req: actix_web::HttpRequest,
) -> Result<impl Responder, ${Name}Error> {
    HttpResponse::Ok().json("todo")
}

pub async fn update(
    id: web::Path<uuid::Uuid>,
    body: web::Json<Update${Name}Schema>,
    data: web::Data<AppState>,
) -> Result<impl Responder, ${Name}Error> {
    HttpResponse::Ok().json("todo")
}

pub async fn delete(
    id: web::Path<uuid::Uuid>,
    data: web::Data<AppState>,
) -> Result<impl Responder, ${Name}Error> {
    HttpResponse::Ok().json("todo")
}
"@ | Set-Content "$dir/handler.rs"

@"
#[derive(Debug, serde::Serialize, serde::Deserialize, sqlx::FromRow)]
pub struct ${Name} {
// pub id: uuid::Uuid,
// pub title: String,
// pub content: String,
// pub published: bool,
// pub created_at: chrono::DateTime<chrono::Utc>,
// pub updated_at: chrono::DateTime<chrono::Utc>,
}
"@ | Set-Content "$dir/model.rs"

@"
use actix_web::http::StatusCode;

#[derive(Debug, thiserror::Error)]
pub enum ${Name}Error {
    #[error("not found: {0}")]
    NotFound(uuid::Uuid),
    #[error("db: {0}")]
    Db(#[from] sqlx::Error),
    #[error("rate limit exceeded")]
    RateLimited,
}
impl actix_web::ResponseError for ${Name}Error {
    fn status_code(&self) -> StatusCode {
        match self {
            ${Name}Error::NotFound(_) => StatusCode::NOT_FOUND,
            ${Name}Error::Db(_) => StatusCode::INTERNAL_SERVER_ERROR,
            ${Name}Error::RateLimited => StatusCode::TOO_MANY_REQUESTS,
        }
    }
    fn error_response(&self) -> actix_web::HttpResponse {
        actix_web::HttpResponse::build(self.status_code())
            .json(serde_json::json!({ "error": self.to_string() }))
    }
}
"@ | Set-Content "$dir/error.rs"

  Write-Host "Created src/$Name/ - add 'mod $Name;' to main.rs" -ForegroundColor Green
}

function MakeMigrations-Rust {
  param(
    [Parameter(Mandatory)]
    [string]$filename,
    [int]$RowCount = 50
  )
  # purpose: fill the gap between sqlx and postgres
  # --- Check if pws is a rust workspace ---
  if (-not (Test-Path "Cargo.toml")) {
    Write-Host "Cargo.toml NotFound" -ForegroundColor Red
    return
  }
  $filename = $filename.ToLower()
  $path = "./src/$filename/model.rs"
  if (-not (Test-Path $path)) {
    Write-Host "$path NotFound" -ForegroundColor Red
    return
  }

  $content = Get-Content $Path -Raw
  $structName = [regex]::Match($content, 'pub struct (\w+)').Groups[1].Value
  $tableName = $structName.ToLower()

  $typeMap = @{
    'uuid::Uuid' = 'UUID'
    'String' = 'TEXT'
    'bool' = 'BOOLEAN'
    'i32' = 'INTEGER'
    'i64' = 'BIGINT'
    'f64' = 'DOUBLE PRECISION'
    'chrono::DateTime<chrono::Utc>' = 'TIMESTAMPTZ'
    'rust_decimal::Decimal' = 'NUMERIC'
  }

  $fields = @()
  $matches = [regex]::Matches($content, 'pub\s+(\w+)\s*:\s*(.+?)\s*[,;]')

  foreach ($m in $matches) {
    $col = $m.Groups[1].Value
    $rustType = $m.Groups[2].Value.Trim()

    $ddl = switch ($rustType) {
      'uuid::Uuid'                    { "    $col UUID PRIMARY KEY DEFAULT gen_random_uuid()" }
      'String'                        { "    $col TEXT NOT NULL" }
      'bool'                          { "    $col BOOLEAN NOT NULL DEFAULT false" }
      'i32'                           { "    $col INTEGER NOT NULL" }
      'i64'                           { "    $col BIGINT NOT NULL" }
      'f64'                           { "    $col DOUBLE PRECISION NOT NULL" }
      'chrono::DateTime<chrono::Utc>' { "    $col TIMESTAMPTZ NOT NULL DEFAULT now()" }
      'rust_decimal::Decimal'         { "    $col NUMERIC NOT NULL" }
      default { Write-Warning "Unknown type: $rustType (column: $col)"; $null }
    }

    if ($ddl) {
      $fake = switch ($rustType) {
        'uuid::Uuid'                    { $null }  # has default, skip in INSERT
        'String'                        { "'${structName} ' || i" }
        'bool'                          { "(i % 3 = 0)" }
        'i32'                           { "i" }
        'i64'                           { "i" }
        'f64'                           { "(i * 1.5)" }
        'chrono::DateTime<chrono::Utc>' { "now() - (i || ' hours')::interval" }
        'rust_decimal::Decimal'         { "(i * 10.5)" }
      }
      $fields += [PSCustomObject]@{ Col = $col; Ddl = $ddl; Fake = $fake }
    }
  }

  # --- CREATE TABLE ---
  $create = "CREATE TABLE IF NOT EXISTS $tableName (`n$($fields.Ddl -join ",`n")`n);"

  # --- INSERT (skip columns with defaults like UUID PK) ---
  $insertCols = $fields | Where-Object { $_.Fake }
  $colList = ($insertCols.Col -join ",")
  $valList = ($insertCols.Fake -join ",`n  ")

  $insert = @"
INSERT INTO $tableName ($colList)
SELECT
$valList
FROM generate_series(1, ${RowCount}) AS i;
"@
  
  # --- Out ---
  $dstDir = "./migrations"
  if (-not (Test-Path dstDir)) {
    New-Item -ItemType Directory -Path $dstDir -Force | Out-Null
  }
  $dstFilename = Join-Path "$dstDir" "${tableName}_init.sql"
  "$create`n`n$insert" | Set-Content $dstFilename
}

function Generate-FakeJson {
  param(
    [Parameter(Mandatory)]
    [string]$filename,
    [int]$Count = 10
  )
  # --- Check if pws is a rust workspace ---
  if (-not (Test-Path "Cargo.toml")) {
    Write-Host "Cargo.toml NotFound" -ForegroundColor Red
    return
  }
  $filename = $filename.ToLower()
  $path = "./src/$filename/model.rs"
  if (-not (Test-Path $path)) {
    Write-Host "$path NotFound" -ForegroundColor Red
    return
  }

  $content = Get-Content $path -Raw
  $structName = [regex]::Match($content, 'pub struct (\w+)').Groups[1].Value
  $matches = [regex]::Matches($content, 'pub\s+(\w+)\s*:\s*(.+?)\s*[,;]')

  $words = @('The','Quick','Brown','Fox','Jumps','Over','Lazy','Dogs','Rust','Actix','Postgres','Async','Service','Handler','Route','Cache','Redis','Docker','Caddy','Nginx','Lorem','Ipsum','Dolor','Sit','Amet')

  $rows = 1..$Count | ForEach-Object {
    $i = $_
    $created = (Get-Date).AddHours(-$i).ToUniversalTime()
    $updated = $created.AddMinutes((Get-Random -Max 60))

    $obj = [ordered]@{}

    foreach ($m in $matches) {
      $col = $m.Groups[1].Value
      $rustType = $m.Groups[2].Value.Trim()

      if ($col -eq 'email') {
        $obj[$col] = "user$i@example.com"
        continue
      }
      if ($col -eq 'phone') {
        $obj[$col] = "555-01$($i.ToString().PadLeft(2,'0'))"
        continue
      }
      switch ($rustType) {
        'uuid::Uuid' {
          $obj[$col] = [guid]::NewGuid().ToString()
        }
        'String' {
          $n = 3 + (Get-Random -Max 4)
          $w = 1..$n | ForEach-Object { $words[(Get-Random -Max $words.Count)] }
          $obj[$col] = ($w -join ' ')
        }
        'bool' {
          $obj[$col] = (Get-Random -Max 3) -eq 0
        }
        'i32' {
          $obj[$col] = $i
        }
        'i64' {
          $obj[$col] = $i
        }
        'f64' {
          $obj[$col] = [math]::Round($i * 1.5, 2)
        }
        'chrono::DateTime<chrono::Utc>' {
          if ($col -eq 'created_at') {
            $obj[$col] = $created.ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
          } else {
            $obj[$col] = $updated.ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
          }
        }
        'rust_decimal::Decimal' {
          $obj[$col] = [math]::Round($i * 10.5, 2)
        }
        default {
          Write-Warning "Unknown type: $rustType (column: $col) — skipping"
        }
      }
    }
    [PSCustomObject]$obj
  }
  $rows | ConvertTo-Json -Depth 5 | set-content "fake_${filename}.json"
}

function New-HttpTest {
  param(
    [Parameter(Mandatory)]
    [string]$obj
  )

@"
@baseUrl = http://0.0.0.0:80
@scope = ${obj}s
@id = f288799e-6a07-4a3a-b20a-50b05df45683

### GET
GET {{baseUrl}}/

### LIST
GET {{baseUrl}}/{{scope}}/

### CREATE
POST {{baseUrl}}/{{scope}}/
Content-Type: application/json

{
  "id":  "ec734b68-c302-4a4a-9644-35ccab287746",
  "title":  "Route Jumps Nginx Service Caddy Over",
  "content":  "Caddy Docker Actix Actix Lazy Ipsum",
  "published":  false,
  "created_at":  "2026-11-20T09:35:47.847Z",
  "updated_at":  "2026-11-20T10:20:47.847Z"
}

### GET
GET {{baseUrl}}/{{scope}}/{{id}}

### UPDATE
PATCH {{baseUrl}}/{{scope}}/{{id}}
Content-Type: application/json

{
  "title":  "updated"
}

### DELTE
DELETE {{baseUrl}}/{{scope}}/{{id}}
"@ | Set-Content "test_${obj}_api.http"
}

Set-Alias gcw Get-Cargo-Workspace
Set-Alias spm Set-ProcMacro-Config
Set-Alias rcc Run-Cargo-Clippy
Set-Alias rcw Run-Cargo-Watch
# Set-Alias rpa Run-PSScript-Analyzer
Set-Alias wls Watch-Lua-Script
Set-Alias gdf Get-Dockfire-Family
Set-Alias grcc Get-Rust-Combinator-Cheatsheet
Set-Alias gpcs Get-Postgres-ConnectionString
Set-Alias iawc Invoke-Api-With-Curl